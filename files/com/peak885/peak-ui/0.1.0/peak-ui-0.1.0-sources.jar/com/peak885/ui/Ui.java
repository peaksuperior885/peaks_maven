package com.peak885.ui;

import com.peak885.ui.rendering.BoxRenderer;
import com.peak885.ui.rendering.TextRenderer;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.lwjgl.opengl.GL11.GL_SCISSOR_TEST;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glScissor;

public final class Ui implements AutoCloseable {

    public static final int CURSOR_ARROW = 0;
    public static final int CURSOR_HAND = 1;
    public static final int CURSOR_IBEAM = 2;

    public enum Font {
        LABEL(12), BODY(14), TITLE(16), HEADLINE(24), DISPLAY(36);

        public final int size;

        Font(int size) {
            this.size = size;
        }
    }

    public static final class Interaction {
        public boolean hovered;
        public boolean pressed;
        public boolean clicked;
    }

    private static final class BoxCmd {
        final Box box;
        final int[] clip;
        final int layer;

        BoxCmd(Box box, int[] clip, int layer) {
            this.box = box;
            this.clip = clip;
            this.layer = layer;
        }
    }

    private static final class TextCmd {
        final Font font;
        final String text;
        final int x;
        final int y;
        final Rgba color;
        final int[] clip;
        final int layer;

        TextCmd(Font font, String text, int x, int y, Rgba color, int[] clip, int layer) {
            this.font = font;
            this.text = text;
            this.x = x;
            this.y = y;
            this.color = color;
            this.clip = clip;
            this.layer = layer;
        }
    }

    private final BoxRenderer boxRenderer;
    private final EnumMap<Font, TextRenderer> fonts = new EnumMap<>(Font.class);
    private final List<BoxCmd> boxCmds = new ArrayList<>();
    private final List<TextCmd> textCmds = new ArrayList<>();
    private final Deque<int[]> clips = new ArrayDeque<>();
    private final Map<String, Box> boxes = new HashMap<>();
    private final Map<String, Float> anims = new HashMap<>();

    public int width;
    public int height;
    public float mouseX;
    public float mouseY;
    public boolean mouseDown;
    public boolean mousePressed;
    public boolean mouseReleased;
    public float scrollY;
    public final StringBuilder typed = new StringBuilder();
    public int backspaces;
    public boolean escapePressed;
    public double time;
    public float dt;

    private double lastTime = -1;
    private String pressedId;
    private int cursorKind;
    private int layer;
    private int maxLayer;
    private int[] appliedClip;
    private boolean appliedValid;

    public Ui(int width, int height) {
        this.width = width;
        this.height = height;
        this.boxRenderer = new BoxRenderer(width, height);
        for (Font f : Font.values()) {
            fonts.put(f, new TextRenderer(width, height, f.size));
        }
    }

    public void beginFrame(int fbWidth, int fbHeight, float mx, float my, double now) {
        double delta = lastTime < 0 ? 0 : now - lastTime;
        lastTime = now;
        dt = (float) Math.max(0.0, Math.min(0.1, delta));
        time = now;
        width = fbWidth;
        height = fbHeight;
        mouseX = mx;
        mouseY = my;

        boxRenderer.resize(fbWidth, fbHeight);
        for (TextRenderer tr : fonts.values()) {
            tr.resize(fbWidth, fbHeight);
        }

        boxCmds.clear();
        textCmds.clear();
        clips.clear();
        layer = 0;
        maxLayer = 0;
        cursorKind = CURSOR_ARROW;
    }

    public void endFrame() {
        if (mouseReleased) {
            pressedId = null;
        }
        mousePressed = false;
        mouseReleased = false;
        scrollY = 0f;
        escapePressed = false;
        typed.setLength(0);
        backspaces = 0;
    }

    public int cursorKind() {
        return cursorKind;
    }

    public void requestCursor(int kind) {
        cursorKind = Math.max(cursorKind, kind);
    }

    public void setLayer(int layer) {
        this.layer = layer;
        this.maxLayer = Math.max(maxLayer, layer);
    }

    public float anim(String id, float target, float speed) {
        float v = anims.containsKey(id) ? anims.get(id) : target;
        v += (target - v) * (1f - (float) Math.exp(-speed * dt));
        anims.put(id, v);
        return v;
    }

    public void pushClip(float x, float y, float w, float h) {
        int x0 = Math.round(x);
        int y0 = Math.round(y);
        int x1 = Math.round(x + w);
        int y1 = Math.round(y + h);
        int[] parent = clips.peek();
        if (parent != null) {
            x0 = Math.max(x0, parent[0]);
            y0 = Math.max(y0, parent[1]);
            x1 = Math.min(x1, parent[0] + parent[2]);
            y1 = Math.min(y1, parent[1] + parent[3]);
        }
        clips.push(new int[]{x0, y0, Math.max(0, x1 - x0), Math.max(0, y1 - y0)});
    }

    public void popClip() {
        clips.pop();
    }

    public boolean hit(float x, float y, float w, float h) {
        if (mouseX < x || mouseX >= x + w || mouseY < y || mouseY >= y + h) {
            return false;
        }
        int[] c = clips.peek();
        return c == null
                || (mouseX >= c[0] && mouseX < c[0] + c[2] && mouseY >= c[1] && mouseY < c[1] + c[3]);
    }

    public Interaction interact(String id, float x, float y, float w, float h) {
        Interaction in = new Interaction();
        in.hovered = hit(x, y, w, h);
        if (in.hovered) {
            requestCursor(CURSOR_HAND);
            if (mousePressed) {
                pressedId = id;
            }
        }
        in.pressed = in.hovered && mouseDown && id.equals(pressedId);
        in.clicked = in.hovered && mouseReleased && id.equals(pressedId);
        return in;
    }

    private Box boxFor(String id) {
        Box b = boxes.get(id);
        if (b == null) {
            b = new Box();
            boxes.put(id, b);
        }
        return b;
    }

    public void rect(float x, float y, float w, float h, Rgba c, float radius) {
        if (c.a <= 0f || w <= 0f || h <= 0f) {
            return;
        }
        boxCmds.add(new BoxCmd(new Box(x, y, w, h, c.r, c.g, c.b, c.a, radius), clips.peek(), layer));
    }

    public void outlined(float x, float y, float w, float h, float radius, float thickness,
                         Rgba border, Rgba fill) {
        rect(x, y, w, h, border, radius);
        rect(x + thickness, y + thickness, w - 2 * thickness, h - 2 * thickness, fill,
                Math.max(0f, radius - thickness));
    }

    public void shadow(float x, float y, float w, float h, float radius) {
        Rgba black = new Rgba(0f, 0f, 0f, 0.05f);
        for (int i = 1; i <= 6; i++) {
            float s = i * 2f;
            rect(x - s, y - s + 4f, w + 2 * s, h + 2 * s, black, radius + s);
        }
    }

    public Interaction surface(String id, float hitX, float hitY, float hitW, float hitH,
                               float x, float y, float w, float h, float radius,
                               Rgba base, Rgba layerColor) {
        Interaction in = interact(id, hitX, hitY, hitW, hitH);
        float hover = anim(id + "#hover", in.hovered ? 1f : 0f, 20f);
        Box box = boxFor(id);
        if (in.hovered && mousePressed) {
            box.press(mouseX - x, mouseY - y, time);
        }
        float amount = 0.08f * hover + (in.pressed ? 0.04f : 0f);
        box.bounds(x, y, Math.max(0f, w), Math.max(0f, h))
                .cornerRadius(radius)
                .color(base.mix(layerColor, amount));
        boxCmds.add(new BoxCmd(box, clips.peek(), layer));
        return in;
    }

    public Interaction surface(String id, float x, float y, float w, float h, float radius,
                               Rgba base, Rgba layerColor) {
        return surface(id, x, y, w, h, x, y, w, h, radius, base, layerColor);
    }

    public void text(Font font, String s, float x, float baseline, Rgba c) {
        if (s == null || s.isEmpty() || c.a <= 0f) {
            return;
        }
        textCmds.add(new TextCmd(font, s, Math.round(x), Math.round(baseline), c, clips.peek(), layer));
    }

    public void textLeft(Font font, String s, float x, float cy, Rgba c) {
        text(font, s, x, cy + font.size * 0.35f, c);
    }

    public void textCentered(Font font, String s, float cx, float cy, Rgba c) {
        text(font, s, cx - textWidth(font, s) / 2f, cy + font.size * 0.35f, c);
    }

    public int textWidth(Font font, String s) {
        return fonts.get(font).getTextWidth(s);
    }

    public String fit(Font font, String s, int maxWidth) {
        if (textWidth(font, s) <= maxWidth) {
            return s;
        }
        String t = s;
        while (t.length() > 1 && textWidth(font, t + "...") > maxWidth) {
            t = t.substring(0, t.length() - 1);
        }
        return t + "...";
    }


    public void flush() {
        for (int l = 0; l <= maxLayer; l++) {
            boxRenderer.begin();
            appliedValid = false;
            for (BoxCmd c : boxCmds) {
                if (c.layer != l) {
                    continue;
                }
                applyClip(c.clip);
                c.box.draw(boxRenderer, time);
            }
            applyClip(null);
            boxRenderer.end();
            appliedValid = false;

            for (TextCmd t : textCmds) {
                if (t.layer != l) {
                    continue;
                }
                applyClip(t.clip);
                fonts.get(t.font).drawText(t.text, t.x, t.y, t.color.r, t.color.g, t.color.b, t.color.a);
            }
            applyClip(null);
        }
    }

    private void applyClip(int[] clip) {
        if (appliedValid && appliedClip == clip) {
            return;
        }
        if (clip == null) {
            glDisable(GL_SCISSOR_TEST);
        } else {
            glEnable(GL_SCISSOR_TEST);
            glScissor(clip[0], height - (clip[1] + clip[3]), clip[2], clip[3]);
        }
        appliedClip = clip;
        appliedValid = true;
    }

    @Override
    public void close() {
        try {
            boxRenderer.close();
        } finally {
            for (TextRenderer tr : fonts.values()) {
                tr.destroy();
            }
        }
    }
}

package com.peak885.ui.rendering;

import com.peak885.ui.shader.ShaderProgram;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryStack;

import java.nio.FloatBuffer;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL20.glUniform1f;
import static org.lwjgl.opengl.GL20.glUniform2f;
import static org.lwjgl.opengl.GL20.glUniform4f;
import static org.lwjgl.system.MemoryStack.stackPush;

/**
 * Immediate-mode UI box renderer with optional rounded corners.
 * <p>
 * Projection is applied through the fixed-function matrix stack (same
 * approach as {@link TextRenderer}). A small GLSL program performs
 * rounded-rectangle coverage via an SDF in the fragment shader.
 * <p>
 * Call {@link #begin()} once per frame, then {@link #drawBox}, then
 * {@link #end()}.
 */
public final class BoxRenderer implements AutoCloseable {

    private final ShaderProgram shader;
    private final int colorLocation;
    private final int boxSizeLocation;
    private final int radiusLocation;
    private final int rippleCenterLocation;
    private final int rippleRadiusLocation;
    private final int rippleOpacityLocation;

    private final Matrix4f projection = new Matrix4f();

    private int width;
    private int height;

    private boolean inBegin;

    /**
     * Creates a box renderer for the given framebuffer size.
     *
     * @param width  framebuffer width in pixels (must be positive)
     * @param height framebuffer height in pixels (must be positive)
     * @throws IllegalArgumentException if dimensions are not positive
     */
    public BoxRenderer(int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException(
                    "Window dimensions must be positive"
            );
        }

        this.width = width;
        this.height = height;

        
        shader = new ShaderProgram(
                "/peakui/shaders/box/box.vert",
                "/peakui/shaders/box/box.frag"
        );

        colorLocation = shader.getUniformLocation("uColor");
        boxSizeLocation = shader.getUniformLocation("uBoxSize");
        radiusLocation = shader.getUniformLocation("uRadius");
        rippleCenterLocation = shader.getUniformLocation("uRippleCenter");
        rippleRadiusLocation = shader.getUniformLocation("uRippleRadius");
        rippleOpacityLocation = shader.getUniformLocation("uRippleOpacity");

        if (colorLocation < 0) {
            System.err.println("[peak-ui] Uniform 'uColor' not found in box shader");
        }
        if (boxSizeLocation < 0) {
            System.err.println("[peak-ui] Uniform 'uBoxSize' not found in box shader");
        }
        if (radiusLocation < 0) {
            System.err.println("[peak-ui] Uniform 'uRadius' not found in box shader");
        }

        updateProjection();
            }

    /**
     * Updates the coordinate system after a window resize.
     * Origin is top-left; Y increases downward.
     *
     * @param width  new framebuffer width
     * @param height new framebuffer height
     */
    public void resize(int width, int height) {
        if (width <= 0 || height <= 0) {
            System.err.println("[peak-ui] Ignoring invalid resize request: " + width + "x" + height);
            return;
        }

        if (this.width == width && this.height == height) {
            return;
        }

        
        this.width = width;
        this.height = height;
        updateProjection();
    }

    private void updateProjection() {
        projection.identity().ortho(
                0.0f, (float) width,
                (float) height, 0.0f,
                -1.0f, 1.0f
        );
            }

    /**
     * Begins drawing UI boxes for this frame.
     * Binds the box shader and loads the orthographic projection
     * into the fixed-function matrix stack.
     */
    public void begin() {
        if (inBegin) {
            System.err.println("[peak-ui] BoxRenderer.begin() called while already in a begin/end pair");
            return;
        }
        inBegin = true;

        glPushAttrib(
                GL_ENABLE_BIT
                        | GL_COLOR_BUFFER_BIT
                        | GL_CURRENT_BIT
                        | GL_DEPTH_BUFFER_BIT
                        | GL_TRANSFORM_BIT
                        | GL_TEXTURE_BIT
        );

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        try (MemoryStack stack = stackPush()) {
            FloatBuffer projBuf = stack.mallocFloat(16);
            projection.get(projBuf);
            glLoadMatrixf(projBuf);
        }

        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();

        shader.bind();

            }

    /**
     * Draws a solid (sharp-cornered) rectangle.
     * Equivalent to {@code drawBox(..., 0.0f)}.
     */
    public void drawBox(
            float x,
            float y,
            float width,
            float height,
            float red,
            float green,
            float blue,
            float alpha
    ) {
        drawBox(x, y, width, height, red, green, blue, alpha, 0.0f);
    }

    /**
     * Draws a rectangle with optional rounded corners.
     *
     * @param x      left position in pixels
     * @param y      top position in pixels
     * @param width  rectangle width
     * @param height rectangle height
     * @param red    red component, 0..1
     * @param green  green component, 0..1
     * @param blue   blue component, 0..1
     * @param alpha  opacity, 0..1
     * @param radius corner radius in pixels (0 = sharp corners)
     */
    public void drawBox(
            float x,
            float y,
            float width,
            float height,
            float red,
            float green,
            float blue,
            float alpha,
            float radius
    ) {
        drawBox(x, y, width, height, red, green, blue, alpha, radius,
                -1.0f, -1.0f, 0.0f, 0.0f);
    }

    /** Draws a rounded box with an animated, clipped press ripple overlay. */
    public void drawRippleBox(float x, float y, float width, float height,
                              float red, float green, float blue, float alpha,
                              float radius, float rippleX, float rippleY,
                              float rippleProgress, float rippleOpacity) {
        float maximumReach = (float) Math.hypot(width, height);
        drawBox(x, y, width, height, red, green, blue, alpha, radius,
                rippleX - width * 0.5f, rippleY - height * 0.5f,
                Math.max(0.0f, rippleProgress) * maximumReach,
                Math.max(0.0f, Math.min(1.0f, rippleOpacity)));
    }

    private void drawBox(float x, float y, float width, float height,
                         float red, float green, float blue, float alpha,
                         float radius, float rippleCenterX, float rippleCenterY,
                         float rippleRadius, float rippleOpacity) {
        if (!inBegin) {
            System.err.println("[peak-ui] drawBox called outside begin/end — calling begin() implicitly");
            begin();
        }

        if (width <= 0.0f || height <= 0.0f) {
                        return;
        }

        // Clamp radius so it never exceeds half the shorter side
        float maxRadius = Math.min(width, height) * 0.5f;
        float r = Math.max(0.0f, Math.min(radius, maxRadius));

        shader.bind();

        glUniform4f(
                colorLocation,
                clamp(red),
                clamp(green),
                clamp(blue),
                clamp(alpha)
        );
        glUniform2f(boxSizeLocation, width, height);
        glUniform1f(radiusLocation, r);
        glUniform2f(rippleCenterLocation, rippleCenterX, rippleCenterY);
        glUniform1f(rippleRadiusLocation, rippleRadius);
        glUniform1f(rippleOpacityLocation, rippleOpacity);

        // Local UV space: centered at the box middle, units = pixels.
        // Matches roundedBoxAlpha(position, uBoxSize * 0.5, uRadius).
        float hx = width * 0.5f;
        float hy = height * 0.5f;

        glBegin(GL_QUADS);
        glTexCoord2f(-hx, -hy);
        glVertex2f(x, y);

        glTexCoord2f(hx, -hy);
        glVertex2f(x + width, y);

        glTexCoord2f(hx, hy);
        glVertex2f(x + width, y + height);

        glTexCoord2f(-hx, hy);
        glVertex2f(x, y + height);
        glEnd();
    }

    /**
     * Ends the UI drawing pass, unbinds the shader, and restores GL state.
     */
    public void end() {
        if (!inBegin) {
            System.err.println("[peak-ui] BoxRenderer.end() called without matching begin()");
            return;
        }

        shader.unbind();

        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();

        glPopAttrib();

        inBegin = false;
            }

    private static float clamp(float value) {
        return Math.max(0.0f, Math.min(1.0f, value));
    }

    @Override
    public void close() {
        if (inBegin) {
            System.err.println("[peak-ui] BoxRenderer closed while still in begin/end pair — forcing end()");
            end();
        }
                shader.close();
    }
}

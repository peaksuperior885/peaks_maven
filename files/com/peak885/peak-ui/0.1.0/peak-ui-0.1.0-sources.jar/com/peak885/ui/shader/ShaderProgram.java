package com.peak885.ui.shader;

import org.lwjgl.BufferUtils;

import java.nio.IntBuffer;

import static org.lwjgl.opengl.GL11.GL_FALSE;
import static org.lwjgl.opengl.GL20.*;

public final class ShaderProgram implements AutoCloseable {

    private final int programId;

    public ShaderProgram(String vertexPath, String fragmentPath) {
        int vertexShader = compileShader(GL_VERTEX_SHADER, Glsl.loadShaderSource(vertexPath));
        int fragmentShader = 0;
        int program = 0;

        try {
            fragmentShader = compileShader(GL_FRAGMENT_SHADER, Glsl.loadShaderSource(fragmentPath));

            program = glCreateProgram();
            glAttachShader(program, vertexShader);
            glAttachShader(program, fragmentShader);
            glLinkProgram(program);

            IntBuffer status = BufferUtils.createIntBuffer(1);
            glGetProgramiv(program, GL_LINK_STATUS, status);

            if (status.get(0) == GL_FALSE) {
                String log = glGetProgramInfoLog(program);
                System.err.println("[peak-ui] Shader program linking failed:\n" + log);
                throw new IllegalStateException("Shader program linking failed:\n" + log);
            }

            this.programId = program;
        } catch (RuntimeException | Error e) {
            if (program != 0) {
                glDeleteProgram(program);
            }
            throw e;
        } finally {
            glDeleteShader(vertexShader);
            if (fragmentShader != 0) {
                glDeleteShader(fragmentShader);
            }
        }
    }

    private static int compileShader(int type, String source) {
        int shader = glCreateShader(type);
        glShaderSource(shader, source);
        glCompileShader(shader);

        IntBuffer status = BufferUtils.createIntBuffer(1);
        glGetShaderiv(shader, GL_COMPILE_STATUS, status);

        if (status.get(0) == GL_FALSE) {
            String log = glGetShaderInfoLog(shader);
            String typeName = type == GL_VERTEX_SHADER ? "Vertex" : "Fragment";
            System.err.println("[peak-ui] " + typeName + " shader compilation failed:\n" + log);
            glDeleteShader(shader);
            throw new IllegalStateException(typeName + " shader compilation failed:\n" + log);
        }
        return shader;
    }

    public void bind() {
        glUseProgram(programId);
    }

    public void unbind() {
        glUseProgram(0);
    }

    public int getUniformLocation(String name) {
        int loc = glGetUniformLocation(programId, name);
        if (loc < 0) {
            System.err.println("[peak-ui] Uniform '" + name + "' not found in program " + programId);
        }
        return loc;
    }

    public int getProgramId() {
        return programId;
    }

    @Override
    public void close() {
        glDeleteProgram(programId);
    }
}

package com.peak885.ui;

import com.peak885.ui.rendering.BoxRenderer;

public final class Box {
    private static final double RIPPLE_DURATION_SECONDS = 0.55;

    private float x;
    private float y;
    private float width;
    private float height;
    private float red;
    private float green;
    private float blue;
    private float opacity = 1.0f;
    private float cornerRadius;
    private float rippleX;
    private float rippleY;
    private double rippleStartedAt = Double.NEGATIVE_INFINITY;

    public Box() {
    }

    public Box(float x, float y, float width, float height,
               float red, float green, float blue, float opacity,
               float cornerRadius) {
        bounds(x, y, width, height);
        this.red = red;
        this.green = green;
        this.blue = blue;
        this.opacity = opacity;
        this.cornerRadius = cornerRadius;
    }

    public Box bounds(float x, float y, float width, float height) {
        if (width < 0 || height < 0) {
            throw new IllegalArgumentException("Box dimensions cannot be negative");
        }
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        return this;
    }

    public Box color(float red, float green, float blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
        return this;
    }

    public Box color(Rgba color) {
        this.red = color.r;
        this.green = color.g;
        this.blue = color.b;
        this.opacity = color.a;
        return this;
    }

    public Box opacity(float opacity) {
        this.opacity = opacity;
        return this;
    }

    public Box cornerRadius(float radius) {
        this.cornerRadius = radius;
        return this;
    }

    public boolean contains(float px, float py) {
        return px >= x && px < x + width && py >= y && py < y + height;
    }

    public void draw(BoxRenderer renderer) {
        renderer.drawBox(x, y, width, height, red, green, blue, opacity, cornerRadius);
    }

    public void press(float localX, float localY, double timeSeconds) {
        rippleX = localX;
        rippleY = localY;
        rippleStartedAt = timeSeconds;
    }

    public void draw(BoxRenderer renderer, double timeSeconds) {
        double elapsed = timeSeconds - rippleStartedAt;
        if (elapsed < 0 || elapsed >= RIPPLE_DURATION_SECONDS) {
            draw(renderer);
            return;
        }
        float progress = (float) (elapsed / RIPPLE_DURATION_SECONDS);
        float easedProgress = 1.0f - (1.0f - progress) * (1.0f - progress);
        float fade = 1.0f - progress;
        renderer.drawRippleBox(x, y, width, height, red, green, blue, opacity,
                cornerRadius, rippleX, rippleY, easedProgress, fade * 0.32f);
    }

    public static Builder at(float x, float y, float width, float height) {
        return new Builder(x, y, width, height);
    }

    public static final class Builder {
        private final float x, y, width, height;
        private float red, green, blue, opacity = 1.0f, cornerRadius;

        private Builder(float x, float y, float width, float height) {
            this.x = x; this.y = y; this.width = width; this.height = height;
        }

        public Builder color(float red, float green, float blue) {
            this.red = red; this.green = green; this.blue = blue;
            return this;
        }

        public Builder opacity(float opacity) { this.opacity = opacity; return this; }
        public Builder cornerRadius(float radius) { this.cornerRadius = radius; return this; }
        public Box build() {
            return new Box(x, y, width, height, red, green, blue, opacity, cornerRadius);
        }
    }
}

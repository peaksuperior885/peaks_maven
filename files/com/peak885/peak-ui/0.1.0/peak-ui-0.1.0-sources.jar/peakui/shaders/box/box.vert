#version 120

void main() {
    // Use the matrix stack (loaded in BoxRenderer.begin) so we stay
    // compatible with the same path TextRenderer already uses.
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
    gl_TexCoord[0] = gl_MultiTexCoord0;
}

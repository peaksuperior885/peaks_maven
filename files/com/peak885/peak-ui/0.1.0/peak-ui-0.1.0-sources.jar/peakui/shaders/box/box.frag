#version 120

#include "/shaders/common/ui_corners.glsl"

uniform vec4 uColor;
uniform vec2 uBoxSize;
uniform float uRadius;
uniform vec2 uRippleCenter;
uniform float uRippleRadius;
uniform float uRippleOpacity;

void main() {
    // Local position: centered at box middle, units = pixels
    // (texcoords are set to ±halfSize in BoxRenderer.drawBox)
    vec2 position = gl_TexCoord[0].xy;

    float alpha = roundedBoxAlpha(
        position,
        uBoxSize * 0.5,
        uRadius
    );

    float rippleDistance = distance(position, uRippleCenter);
    float ripple = (1.0 - smoothstep(uRippleRadius - 5.0, uRippleRadius + 5.0, rippleDistance))
            * uRippleOpacity;
    vec3 rippleColor = mix(uColor.rgb, vec3(1.0), 0.28);
    vec3 color = mix(uColor.rgb, rippleColor, ripple);
    gl_FragColor = vec4(color, uColor.a * alpha);
}

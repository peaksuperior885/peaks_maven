#version 120

uniform sampler2D uTexture;
uniform vec4 uColor;
uniform int uIsColorGlyph; // 1 = color emoji (premultiplied / replace), 0 = gray modulate
varying vec2 vTexCoord;

void main() {
    vec4 tex = texture2D(uTexture, vTexCoord);
    if (uIsColorGlyph != 0) {
        // Color glyphs (emoji): use texel RGB, modulate alpha by uColor.a
        gl_FragColor = vec4(tex.rgb, tex.a * uColor.a);
    } else {
        // Gray glyphs: modulate by uColor
        gl_FragColor = vec4(uColor.rgb, tex.a * uColor.a);
    }
}

package com.peak885.ui.components;

import com.peak885.ui.Box;
import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class Buttons {
    private final Ui ui;

    public Buttons(Ui ui) {
        this.ui = ui;
    }

    public Ui.Interaction filledButton(String id, float x, float y, float w, float h, float radius) {
        Ui.Interaction in = ui.surface(id, x, y, w, h, radius, Theme.PRIMARY, Theme.ON_PRIMARY);
        if (in.focused) ui.focusRing(x, y, w, h, radius);
        return in;
    }

    public Ui.Interaction tonalButton(String id, float x, float y, float w, float h, float radius) {
        Ui.Interaction in = ui.surface(id, x, y, w, h, radius, Theme.PRIMARY_CONTAINER, Theme.ON_SURFACE);
        if (in.focused) ui.focusRing(x, y, w, h, radius);
        return in;
    }

    public Ui.Interaction outlinedButton(String id, float x, float y, float w, float h, float radius) {
        Ui.Interaction in = ui.interact(id, x, y, w, h);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 20f);
        Box box = ui.boxFor(id);
        if (in.hovered && ui.mousePressed) {
            box.press(ui.mouseX - x, ui.mouseY - y, ui.time);
        }
        float amount = 0.12f * hover + (in.pressed ? 0.06f : 0f);
        Rgba fill = Theme.SURFACE.mix(Theme.PRIMARY, amount).alpha(amount > 0.01f ? 0.55f * amount + 0.08f : 0.04f);
        box.bounds(x, y, Math.max(0f, w), Math.max(0f, h))
                .cornerRadius(radius)
                .color(fill)
                .border(1.25f, Theme.OUTLINE.mix(Theme.PRIMARY, hover * 0.4f));
        ui.enqueueBox(box);
        return in;
    }

    public Ui.Interaction textButton(String id, float x, float y, float w, float h, float radius) {
        Ui.Interaction in = ui.interact(id, x, y, w, h);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 22f);
        if (hover > 0.01f || in.pressed) {
            Box box = ui.boxFor(id);
            if (in.hovered && ui.mousePressed) {
                box.press(ui.mouseX - x, ui.mouseY - y, ui.time);
            }
            float amount = 0.10f * hover + (in.pressed ? 0.06f : 0f);
            Rgba fill = Theme.PRIMARY.alpha(amount);
            box.bounds(x, y, Math.max(0f, w), Math.max(0f, h))
                    .cornerRadius(radius)
                    .color(fill);
            ui.enqueueBox(box);
        }
        return in;
    }

    public Ui.Interaction fab(String id, float x, float y, float size) {
        float s = Math.max(40f, size);
        ui.elevatedShadow(x, y, s, s, s * 0.5f, 8f);
        Ui.Interaction in = ui.surface(id, x, y, s, s, s * 0.5f, Theme.PRIMARY_CONTAINER, Theme.ON_SURFACE);
        return in;
    }

    public Ui.Interaction iconButton(String id, float x, float y, float size) {
        float s = Math.max(28f, size);
        Ui.Interaction in = ui.interact(id, x, y, s, s);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 22f);
        if (hover > 0.01f || in.pressed) {
            float amount = 0.10f * hover + (in.pressed ? 0.06f : 0f);
            Box box = ui.boxFor(id);
            if (in.hovered && ui.mousePressed) {
                box.press(ui.mouseX - x, ui.mouseY - y, ui.time);
            }
            box.bounds(x, y, s, s)
                    .cornerRadius(s * 0.5f)
                    .color(Theme.ON_SURFACE.alpha(amount));
            ui.enqueueBox(box);
        }
        return in;
    }
}

package com.peak885.ui;

import com.peak885.ui.components.*;
import com.peak885.ui.rendering.*;

import java.util.*;

import static org.lwjgl.opengl.GL11.*;

public final class Ui implements AutoCloseable {

    public static final int CURSOR_ARROW = 0;
    public static final int CURSOR_HAND = 1;
    public static final int CURSOR_IBEAM = 2;

    public enum Font {
        LABEL(12), BODY(14), TITLE(16), HEADLINE(24), DISPLAY(36);

        public final int size;

        Font(int size) {
            this.size = size;
        }
    }

    public static final class Interaction {
        public boolean hovered;
        public boolean pressed;
        public boolean clicked;
        public boolean focused;
    }

    public interface TextBackend {
        int textWidth(Font font, String text);
        void drawText(Font font, String text, int x, int baseline, Rgba color);
    }

    @FunctionalInterface
    public interface CustomDraw {
        void draw(DrawContext ctx);
    }

    public final class DrawContext {
        private final int[] clip;
        private final int layer;

        private DrawContext(int[] clip, int layer) {
            this.clip = clip;
            this.layer = layer;
        }

        public int width() { return Ui.this.width; }
        public int height() { return Ui.this.height; }

        public int layer() { return layer; }

        public int[] clip() { return clip; }

        public BoxRenderer boxRenderer() { return boxRenderer; }

        public void drawText(Font font, String text, int x, int baseline, Rgba color) {
            if (text == null || text.isEmpty() || color == null || color.a <= 0f) return;
            if (textBackend != null) {
                textBackend.drawText(font, text, x, baseline, color);
            } else {
                fonts.get(font).drawText(text, x, baseline, color.r, color.g, color.b, color.a);
            }
        }

        public int textWidth(Font font, String text) {
            return Ui.this.textWidth(font, text);
        }
    }

    private static final class BoxCmd {
        final Box box;
        final int[] clip;
        final int layer;

        BoxCmd(Box box, int[] clip, int layer) {
            this.box = box;
            this.clip = clip;
            this.layer = layer;
        }
    }

    private static final class TextCmd {
        final Font font;
        final String text;
        final int x;
        final int y;
        final Rgba color;
        final int[] clip;
        final int layer;

        TextCmd(Font font, String text, int x, int y, Rgba color, int[] clip, int layer) {
            this.font = font;
            this.text = text;
            this.x = x;
            this.y = y;
            this.color = color;
            this.clip = clip;
            this.layer = layer;
        }
    }

    private static final class CustomCmd {
        final CustomDraw draw;
        final int[] clip;
        final int layer;

        CustomCmd(CustomDraw draw, int[] clip, int layer) {
            this.draw = draw;
            this.clip = clip;
            this.layer = layer;
        }
    }

    private final BoxRenderer boxRenderer;
    private final TextBackend textBackend;

    // Component modules (public API still lives on Ui and delegates here)
    private final Buttons buttons;
    private final Surfaces surfaces;
    private final Navigation navigation;
    private final Fields fields;
    private final Feedback feedback;
    private final GameWidgets gameWidgets;
    private final Scroll scroll;
    private final Drag drag;
    private final Menus menus;
    private final Panels panels;
    private final EnumMap<Font, TextRenderer> fonts = new EnumMap<>(Font.class);
    private final List<BoxCmd> boxCmds = new ArrayList<>();
    private final List<TextCmd> textCmds = new ArrayList<>();
    private final List<CustomCmd> customCmds = new ArrayList<>();
    private final Deque<int[]> clips = new ArrayDeque<>();
    private final Map<String, Box> boxes = new HashMap<>();
    private final Map<String, Float> anims = new HashMap<>();

    public int width;
    public int height;
    public float mouseX;
    public float mouseY;
    public boolean mouseDown;
    public boolean mousePressed;
    public boolean mouseReleased;
    public boolean rightMouseDown;
    public boolean rightMousePressed;
    public boolean rightMouseReleased;
    public float scrollY;
    public final StringBuilder typed = new StringBuilder();
    public int backspaces;
    public boolean escapePressed;
    public boolean tabPressed;
    public boolean shiftDown;
    public boolean enterPressed;
    public double time;
    public float dt;

    private double lastTime = -1;
    private String pressedId;
    private String focusedId;
    private int cursorKind;
    private int layer;
    private int maxLayer;
    private int[] appliedClip;
    private boolean appliedValid;

    private final List<String> focusOrder = new ArrayList<>();
    private List<String> focusOrderPrev = new ArrayList<>();




    public Ui(int width, int height) {
        this(width, height, null);
    }

    public Ui(int width, int height, TextBackend textBackend) {
        this.width = width;
        this.height = height;
        this.textBackend = textBackend;
        this.boxRenderer = new BoxRenderer(width, height);
        if (textBackend == null) {
            for (Font f : Font.values()) fonts.put(f, new TextRenderer(width, height, f.size));
        }
        this.buttons = new Buttons(this);
        this.surfaces = new Surfaces(this);
        this.navigation = new Navigation(this);
        this.fields = new Fields(this);
        this.feedback = new Feedback(this);
        this.gameWidgets = new GameWidgets(this);
        this.scroll = new Scroll(this);
        this.drag = new Drag(this);
        this.menus = new Menus(this);
        this.panels = new Panels(this);
    }
    public void beginFrame(int fbWidth, int fbHeight, float mx, float my, double now) {
        double delta = lastTime < 0 ? 0 : now - lastTime;
        lastTime = now;
        dt = (float) Math.max(0.0, Math.min(0.1, delta));
        time = now;
        width = fbWidth;
        height = fbHeight;
        mouseX = mx;
        mouseY = my;

        boxRenderer.resize(fbWidth, fbHeight);
        for (TextRenderer tr : fonts.values()) {
            tr.resize(fbWidth, fbHeight);
        }

        boxCmds.clear();
        textCmds.clear();
        customCmds.clear();
        clips.clear();
        layer = 0;
        maxLayer = 0;
        cursorKind = CURSOR_ARROW;

        if (tabPressed && !focusOrderPrev.isEmpty()) {
            int idx = focusedId != null ? focusOrderPrev.indexOf(focusedId) : -1;
            int n = focusOrderPrev.size();
            int next = idx < 0 ? (shiftDown ? n - 1 : 0) : Math.floorMod(idx + (shiftDown ? -1 : 1), n);
            focusedId = focusOrderPrev.get(next);
        }
        if (escapePressed) {
            focusedId = null;
        }
        focusOrder.clear();
    }

    public void endFrame() {
        if (mouseReleased) {
            pressedId = null;
        }
        mousePressed = false;
        mouseReleased = false;
        rightMousePressed = false;
        rightMouseReleased = false;
        scrollY = 0f;
        escapePressed = false;
        typed.setLength(0);
        backspaces = 0;
        tabPressed = false;
        enterPressed = false;
        focusOrderPrev = new ArrayList<>(focusOrder);
    }

    public String focusedId() {
        return focusedId;
    }

    public void clearFocus() {
        focusedId = null;
    }

    public boolean isFocused(String id) {
        return id != null && id.equals(focusedId);
    }

    public int cursorKind() {
        return cursorKind;
    }

    public void requestCursor(int kind) {
        cursorKind = Math.max(cursorKind, kind);
    }

    public void setLayer(int layer) {
        this.layer = layer;
        this.maxLayer = Math.max(maxLayer, layer);
    }

    public float anim(String id, float target, float speed) {
        float v = anims.containsKey(id) ? anims.get(id) : target;
        v += (target - v) * (1f - (float) Math.exp(-speed * dt));
        anims.put(id, v);
        return v;
    }

    public void pushClip(float x, float y, float w, float h) {
        int x0 = Math.round(x);
        int y0 = Math.round(y);
        int x1 = Math.round(x + w);
        int y1 = Math.round(y + h);
        int[] parent = clips.peek();
        if (parent != null) {
            x0 = Math.max(x0, parent[0]);
            y0 = Math.max(y0, parent[1]);
            x1 = Math.min(x1, parent[0] + parent[2]);
            y1 = Math.min(y1, parent[1] + parent[3]);
        }
        clips.push(new int[]{x0, y0, Math.max(0, x1 - x0), Math.max(0, y1 - y0)});
    }

    public void popClip() {
        clips.pop();
    }

    public boolean hit(float x, float y, float w, float h) {
        if (mouseX < x || mouseX >= x + w || mouseY < y || mouseY >= y + h) {
            return false;
        }
        int[] c = clips.peek();
        return c == null
                || (mouseX >= c[0] && mouseX < c[0] + c[2] && mouseY >= c[1] && mouseY < c[1] + c[3]);
    }

    public Interaction interact(String id, float x, float y, float w, float h) {
        focusOrder.add(id);
        Interaction in = new Interaction();
        in.hovered = hit(x, y, w, h);
        if (in.hovered) {
            requestCursor(CURSOR_HAND);
            if (mousePressed) {
                pressedId = id;
                focusedId = id;
            }
        }
        in.pressed = in.hovered && mouseDown && id.equals(pressedId);
        in.focused = id.equals(focusedId);
        in.clicked = (in.hovered && mouseReleased && id.equals(pressedId))
                || (enterPressed && in.focused);
        return in;
    }

    public void focusRing(float x, float y, float w, float h, float radius) {
        rect(x - 3f, y - 3f, w + 6f, h + 6f, Theme.PRIMARY.alpha(0.001f), radius + 3f,
                2f, Theme.PRIMARY.alpha(0.9f), 0f);
    }

    /** Shared box state for interactive surfaces (ripple, etc.). Used by component modules. */
    public Box boxFor(String id) {
        Box b = boxes.get(id);
        if (b == null) {
            b = new Box();
            boxes.put(id, b);
        }
        return b;
    }

    /** Enqueue a fully configured box for the current layer/clip. Used by component modules. */
    public void enqueueBox(Box box) {
        boxCmds.add(new BoxCmd(box, clips.peek(), layer));
    }

    public void setFocusedId(String id) {
        focusedId = id;
    }

    public String pressedId() {
        return pressedId;
    }

    public int layer() {
        return layer;
    }

    public int maxLayer() {
        return maxLayer;
    }

    public void rect(float x, float y, float w, float h, Rgba c, float radius) {
        rect(x, y, w, h, c, radius, 0f, null, 0f);
    }

    public void rect(float x, float y, float w, float h, Rgba c, float radius,
                     float borderWidth, Rgba border, float softness) {
        if (c.a <= 0f || w <= 0f || h <= 0f) {
            return;
        }
        Box box = new Box(x, y, w, h, c.r, c.g, c.b, c.a, radius);
        if (borderWidth > 0f && border != null) {
            box.border(borderWidth, border);
        }
        if (softness > 0f) {
            box.softness(softness);
        }
        boxCmds.add(new BoxCmd(box, clips.peek(), layer));
    }

    public void outlined(float x, float y, float w, float h, float radius, float thickness,
                         Rgba border, Rgba fill) {
        rect(x, y, w, h, border, radius);
        rect(x + thickness, y + thickness, w - 2 * thickness, h - 2 * thickness, fill,
                Math.max(0f, radius - thickness));
    }

    public void shadow(float x, float y, float w, float h, float radius) {
        Rgba black = new Rgba(0f, 0f, 0f, 0.05f);
        for (int i = 1; i <= 6; i++) {
            float s = i * 2f;
            rect(x - s, y - s + 4f, w + 2 * s, h + 2 * s, black, radius + s);
        }
    }

    public Interaction surface(String id, float hitX, float hitY, float hitW, float hitH,
                               float x, float y, float w, float h, float radius,
                               Rgba base, Rgba layerColor) {
        Interaction in = interact(id, hitX, hitY, hitW, hitH);
        float hover = anim(id + "#hover", in.hovered ? 1f : 0f, 20f);
        Box box = boxFor(id);
        if (in.hovered && mousePressed) {
            box.press(mouseX - x, mouseY - y, time);
        }
        float amount = 0.08f * hover + (in.pressed ? 0.04f : 0f);
        box.bounds(x, y, Math.max(0f, w), Math.max(0f, h))
                .cornerRadius(radius)
                .color(base.mix(layerColor, amount))
                .border(0f, 0f, 0f, 0f, 0f)
                .softness(0f);
        boxCmds.add(new BoxCmd(box, clips.peek(), layer));
        return in;
    }

    public Interaction surface(String id, float x, float y, float w, float h, float radius,
                               Rgba base, Rgba layerColor) {
        return surface(id, x, y, w, h, x, y, w, h, radius, base, layerColor);
    }


    // ---- surfaces / buttons (delegated) ----

    public void card(float x, float y, float w, float h, float radius, float elevation, Rgba fill) {
        surfaces.card(x, y, w, h, radius, elevation, fill);
    }

    public void outlinedCard(float x, float y, float w, float h, float radius, Rgba fill, Rgba outline) {
        surfaces.outlinedCard(x, y, w, h, radius, fill, outline);
    }

    public void glass(float x, float y, float w, float h, float radius) {
        surfaces.glass(x, y, w, h, radius);
    }

    public void glass(float x, float y, float w, float h, float radius,
                      Rgba fill, Rgba border, float softness) {
        surfaces.glass(x, y, w, h, radius, fill, border, softness);
    }

    public Interaction glassSurface(String id, float x, float y, float w, float h, float radius) {
        return surfaces.glassSurface(id, x, y, w, h, radius);
    }

    public Interaction glassSurface(String id, float x, float y, float w, float h, float radius,
                                    Rgba base, Rgba border, float softness) {
        return surfaces.glassSurface(id, x, y, w, h, radius, base, border, softness);
    }

    public Interaction filledButton(String id, float x, float y, float w, float h, float radius) {
        return buttons.filledButton(id, x, y, w, h, radius);
    }

    public Interaction tonalButton(String id, float x, float y, float w, float h, float radius) {
        return buttons.tonalButton(id, x, y, w, h, radius);
    }

    public Interaction outlinedButton(String id, float x, float y, float w, float h, float radius) {
        return buttons.outlinedButton(id, x, y, w, h, radius);
    }

    public Interaction textButton(String id, float x, float y, float w, float h, float radius) {
        return buttons.textButton(id, x, y, w, h, radius);
    }

    public void divider(float x, float y, float w) {
        surfaces.divider(x, y, w);
    }

    public void elevatedShadow(float x, float y, float w, float h, float radius, float elevation) {
        surfaces.elevatedShadow(x, y, w, h, radius, elevation);
    }

    public Interaction chip(String id, float x, float y, float w, float h, boolean selected) {
        return surfaces.chip(id, x, y, w, h, selected);
    }

    public static final class TabsResult {
        public int selected;
        public boolean changed;
        public float indicatorX;
        public float indicatorW;
    }

    public TabsResult tabs(String id, float x, float y, float width, float height,
                           String[] labels, int selected) {
        return navigation.tabs(id, x, y, width, height, labels, selected);
    }

    public TabsResult tabs(String id, float x, float y, float width, float height,
                           String[] labels, int selected,
                           Rgba indicatorColor, Rgba selectedLabel, Rgba unselectedLabel) {
        return navigation.tabs(id, x, y, width, height, labels, selected, indicatorColor, selectedLabel, unselectedLabel);
    }

    public static final class DropdownResult {
        public int selected;
        public boolean changed;
        public boolean expanded;
    }

    public DropdownResult dropdown(String id, float x, float y, float w, float h,
                                   String[] options, int selected) {
        return navigation.dropdown(id, x, y, w, h, options, selected);
    }

    public TabsResult tabsAuto(String id, float x, float y, float maxWidth, float height,
                               String[] labels, int selected) {
        return navigation.tabsAuto(id, x, y, maxWidth, height, labels, selected);
    }

    public static final class TextFieldResult {
        public String text;
        public boolean focused;
        public boolean changed;
        public boolean submitted;
        public Interaction interaction = new Interaction();
    }

    public TextFieldResult textField(String id, float x, float y, float w, float h,
                                     String value, String placeholder) {
        return fields.textField(id, x, y, w, h, value, placeholder);
    }

    public TextFieldResult searchField(String id, float x, float y, float w, float h,
                                       String value, String placeholder) {
        return fields.searchField(id, x, y, w, h, value, placeholder);
    }

    public boolean toggle(String id, float x, float y, float height, boolean on) {
        return fields.toggle(id, x, y, height, on);
    }

    public boolean checkbox(String id, float x, float y, float size, boolean checked) {
        return fields.checkbox(id, x, y, size, checked);
    }

    public void progressBar(float x, float y, float w, float h, float progress) {
        feedback.progressBar(x, y, w, h, progress);
    }

    public void progressBar(float x, float y, float w, float h, float progress, Rgba track, Rgba fill) {
        feedback.progressBar(x, y, w, h, progress, track, fill);
    }

    public void progressIndeterminate(String id, float x, float y, float w, float h) {
        feedback.progressIndeterminate(id, x, y, w, h);
    }

    public float slider(String id, float x, float y, float w, float h, float value, float min, float max) {
        return fields.slider(id, x, y, w, h, value, min, max);
    }

    public Interaction fab(String id, float x, float y, float size) {
        return buttons.fab(id, x, y, size);
    }

    public Interaction iconButton(String id, float x, float y, float size) {
        return buttons.iconButton(id, x, y, size);
    }

    public int segmented(String id, float x, float y, float w, float h, String[] labels, int selected) {
        return fields.segmented(id, x, y, w, h, labels, selected);
    }

    public Interaction listItem(String id, float x, float y, float w, float h,
                                String title, String supporting) {
        return feedback.listItem(id, x, y, w, h, title, supporting);
    }

    public void badge(float anchorRight, float anchorTop, int count) {
        feedback.badge(anchorRight, anchorTop, count);
    }

    public void accentRail(float x, float y, float h, float thickness, Rgba color) {
        feedback.accentRail(x, y, h, thickness, color);
    }

    public void glowOrb(float cx, float cy, float radius, Rgba color) {
        feedback.glowOrb(cx, cy, radius, color);
    }

    public void statusPill(float x, float y, float h, String label, Rgba statusColor) {
        feedback.statusPill(x, y, h, label, statusColor);
    }

    public void tooltip(float x, float y, String message) {
        feedback.tooltip(x, y, message);
    }

    public Interaction proximityPrompt(String id, float centerX, float centerY,
                                       String key, String action, float visibility) {
        return gameWidgets.proximityPrompt(id, centerX, centerY, key, action, visibility);
    }

    public Interaction proximityPrompt(String id, float centerX, float centerY,
                                       String key, String action) {
        return gameWidgets.proximityPrompt(id, centerX, centerY, key, action);
    }
    public void custom(CustomDraw draw) {
        if (draw == null) {
            return;
        }
        customCmds.add(new CustomCmd(draw, clips.peek(), layer));
        maxLayer = Math.max(maxLayer, layer);
    }

    public void text(Font font, String s, float x, float baseline, Rgba c) {
        if (s == null || s.isEmpty() || c.a <= 0f) {
            return;
        }
        textCmds.add(new TextCmd(font, s, Math.round(x), Math.round(baseline), c, clips.peek(), layer));
    }

    public void textLeft(Font font, String s, float x, float cy, Rgba c) {
        text(font, s, x, cy + font.size * 0.35f, c);
    }

    public void textCentered(Font font, String s, float cx, float cy, Rgba c) {
        text(font, s, cx - textWidth(font, s) / 2f, cy + font.size * 0.35f, c);
    }

    public int textWidth(Font font, String s) {
        return textBackend != null ? textBackend.textWidth(font, s) : fonts.get(font).getTextWidth(s);
    }

    public String fit(Font font, String s, int maxWidth) {
        if (textWidth(font, s) <= maxWidth) {
            return s;
        }
        String t = s;
        while (t.length() > 1 && textWidth(font, t + "...") > maxWidth) {
            t = t.substring(0, t.length() - 1);
        }
        return t + "...";
    }


    public static final class ScrollResult {
        public float offsetX, offsetY;
        public float maxOffsetX, maxOffsetY;
        public boolean canScrollX, canScrollY;
    }

    public ScrollResult beginScroll(String id, float x, float y, float w, float h,
                                    float contentWidth, float contentHeight) {
        return scroll.beginScroll(id, x, y, w, h, contentWidth, contentHeight);
    }

    public void endScroll() {
        scroll.endScroll();
    }

    public static final class DragResult {
        public boolean started;
        public boolean dragging;
        public boolean released;
        public float dx, dy;
        public float totalDx, totalDy;
    }

    public DragResult dragZone(String id, float x, float y, float w, float h) {
        return drag.dragZone(id, x, y, w, h);
    }

    public boolean isDragging(String id) {
        return drag.isDragging(id);
    }

    public String activeDragId() {
        return drag.activeDragId();
    }

    public void setDragPayload(Object payload) {
        drag.setDragPayload(payload);
    }

    public Object dragPayload() {
        return drag.dragPayload();
    }

    public static final class PanelDragResult {
        public float x, y;
        public boolean dragging;
    }

    public PanelDragResult draggablePanel(String id, float x, float y,
                                          float handleX, float handleY, float handleW, float handleH) {
        return drag.draggablePanel(id, x, y, handleX, handleY, handleW, handleH);
    }

    public static final class ReorderResult {
        public int[] order;
        public boolean changed;
        public int draggingSlot = -1;
    }

    public ReorderResult reorderableList(String id, float x, float y, float w, float rowH, String[] labels, int[] order) {
        return drag.reorderableList(id, x, y, w, rowH, labels, order);
    }

    public static final class MenuItem {
        public final String label;
        public final boolean enabled;
        public final MenuItem[] children;

        public MenuItem(String label) {
            this(label, true, null);
        }

        public MenuItem(String label, boolean enabled) {
            this(label, enabled, null);
        }

        public MenuItem(String label, MenuItem[] children) {
            this(label, true, children);
        }

        private MenuItem(String label, boolean enabled, MenuItem[] children) {
            this.label = label;
            this.enabled = enabled;
            this.children = children;
        }

        public static MenuItem separator() {
            return new MenuItem(null);
        }

        public boolean isSeparator() {
            return label == null;
        }

        public boolean hasChildren() {
            return children != null && children.length > 0;
        }
    }

    public void openContextMenu(String id, float atX, float atY) {
        menus.openContextMenu(id, atX, atY);
    }

    public boolean isContextMenuOpen(String id) {
        return menus.isContextMenuOpen(id);
    }

    public void closeContextMenu() {
        menus.closeContextMenu();
    }

    public MenuItem contextMenu(String id, MenuItem[] items) {
        return menus.contextMenu(id, items);
    }

    public static final class VirtualRange {
        public int firstIndex;
        public int lastIndexExclusive;
    }

    public VirtualRange virtualRange(float scrollOffset, float viewportHeight, float rowHeight, int itemCount) {
        return scroll.virtualRange(scrollOffset, viewportHeight, rowHeight, itemCount);
    }

    public static final class SplitResult {
        public float position;
        public boolean dragging;
    }

    public SplitResult splitPane(String id, float x, float y, float w, float h, boolean vertical,
                                 float position, float min, float max) {
        return panels.splitPane(id, x, y, w, h, vertical, position, min, max);
    }

    public static final class ResizeResult {
        public float width, height;
        public boolean resizing;
    }

    public ResizeResult resizablePanel(String id, float x, float y, float width, float height,
                                       float minW, float minH, float maxW, float maxH) {
        return panels.resizablePanel(id, x, y, width, height, minW, minH, maxW, maxH);
    }

    public static final class TitleBarResult {
        public float dx, dy;
        public boolean dragging;
        public boolean closeClicked;
    }

    public TitleBarResult panelTitleBar(String id, float x, float y, float w, float h, String title, boolean closable) {
        return panels.panelTitleBar(id, x, y, w, h, title, closable);
    }

    public void flush() {
        for (int l = 0; l <= maxLayer; l++) {
            boxRenderer.begin();
            appliedValid = false;
            for (BoxCmd c : boxCmds) {
                if (c.layer != l) {
                    continue;
                }
                applyClip(c.clip);
                c.box.draw(boxRenderer, time);
            }
            applyClip(null);
            boxRenderer.end();
            appliedValid = false;

            for (TextCmd t : textCmds) {
                if (t.layer != l) {
                    continue;
                }
                applyClip(t.clip);
                if (textBackend != null) textBackend.drawText(t.font, t.text, t.x, t.y, t.color);
                else fonts.get(t.font).drawText(t.text, t.x, t.y, t.color.r, t.color.g, t.color.b, t.color.a);
            }
            applyClip(null);

            for (CustomCmd c : customCmds) {
                if (c.layer != l) {
                    continue;
                }
                applyClip(c.clip);
                c.draw.draw(new DrawContext(c.clip, c.layer));
            }
            applyClip(null);
        }
    }

    private void applyClip(int[] clip) {
        if (appliedValid && appliedClip == clip) {
            return;
        }
        if (clip == null) {
            glDisable(GL_SCISSOR_TEST);
        } else {
            glEnable(GL_SCISSOR_TEST);
            glScissor(clip[0], height - (clip[1] + clip[3]), clip[2], clip[3]);
        }
        appliedClip = clip;
        appliedValid = true;
    }

    @Override
    public void close() {
        try {
            boxRenderer.close();
        } finally {
            for (TextRenderer tr : fonts.values()) {
                tr.destroy();
            }
        }
    }
}

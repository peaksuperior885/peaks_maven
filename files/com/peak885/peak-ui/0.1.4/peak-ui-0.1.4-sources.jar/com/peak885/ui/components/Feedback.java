package com.peak885.ui.components;

import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class Feedback {
    private final Ui ui;

    public Feedback(Ui ui) {
        this.ui = ui;
    }

    public void progressBar(float x, float y, float w, float h, float progress) {
        progressBar(x, y, w, h, progress, Theme.SURFACE_CONTAINER_HIGH, Theme.PRIMARY);
    }

    public void progressBar(float x, float y, float w, float h, float progress, Rgba track, Rgba fill) {
        float p = Math.max(0f, Math.min(1f, progress));
        float r = h * 0.5f;
        ui.rect(x, y, w, h, track, r);
        if (p > 0.001f) {
            ui.rect(x, y, Math.max(h, w * p), h, fill, r);
        }
    }

    public void progressIndeterminate(String id, float x, float y, float w, float h) {
        float r = h * 0.5f;
        ui.rect(x, y, w, h, Theme.SURFACE_CONTAINER_HIGH, r);
        float cycle = (float) ((ui.time * 0.85) % 1.6);
        float head = cycle < 1f ? cycle : 1f;
        float tail = cycle < 0.6f ? 0f : (cycle - 0.6f) / 1f;
        float left = x + w * tail;
        float right = x + w * Math.min(1f, head * 0.55f + tail);
        float bw = Math.max(h, right - left);
        // Keep a stable anim key so callers can have multiple bars
        ui.anim(id + "#ind", head, 1f);
        ui.pushClip(x, y, w, h);
        ui.rect(left, y, bw, h, Theme.PRIMARY, r);
        ui.popClip();
    }
    public Ui.Interaction listItem(String id, float x, float y, float w, float h,
                                String title, String supporting) {
        Ui.Interaction in = ui.interact(id, x, y, w, h);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 20f);
        if (hover > 0.01f || in.pressed) {
            float amount = 0.07f * hover + (in.pressed ? 0.04f : 0f);
            ui.rect(x, y, w, h, Theme.ON_SURFACE.alpha(amount), 8f);
        }
        float textX = x + 16f;
        if (title != null) {
            float ty = supporting != null && !supporting.isEmpty()
                    ? y + h * 0.38f
                    : y + h * 0.5f;
            ui.textLeft(Ui.Font.BODY, ui.fit(Ui.Font.BODY, title, (int) (w - 32f)), textX, ty, Theme.ON_SURFACE);
        }
        if (supporting != null && !supporting.isEmpty()) {
            ui.textLeft(Ui.Font.LABEL, ui.fit(Ui.Font.LABEL, supporting, (int) (w - 32f)),
                    textX, y + h * 0.68f, Theme.ON_SURFACE_VARIANT);
        }
        return in;
    }

    public void badge(float anchorRight, float anchorTop, int count) {
        if (count == 0) {
            return;
        }
        if (count < 0) {
            float d = 10f;
            ui.rect(anchorRight - d * 0.5f, anchorTop - d * 0.5f, d, d, Theme.PRIMARY, d * 0.5f);
            return;
        }
        String label = count > 99 ? "99+" : Integer.toString(count);
        float tw = ui.textWidth(Ui.Font.LABEL, label);
        float bw = Math.max(18f, tw + 10f);
        float bh = 18f;
        ui.rect(anchorRight - bw * 0.5f, anchorTop - bh * 0.5f, bw, bh, Theme.PRIMARY, bh * 0.5f);
        ui.textCentered(Ui.Font.LABEL, label, anchorRight, anchorTop, Theme.ON_PRIMARY);
    }

    public void accentRail(float x, float y, float h, float thickness, Rgba color) {
        float t = Math.max(2f, thickness);
        ui.rect(x, y, t, h, color, t * 0.5f);
        ui.rect(x + t * 0.15f, y, t * 0.7f, h, color.alpha(color.a * 0.35f), t * 0.35f, 0f, null, t);
    }

    public void glowOrb(float cx, float cy, float radius, Rgba color) {
        float r = Math.max(8f, radius);
        ui.rect(cx - r, cy - r, r * 2f, r * 2f, color, r, 0f, null, r * 0.65f);
    }

    public void statusPill(float x, float y, float h, String label, Rgba statusColor) {
        if (label == null) label = "";
        float pad = 10f;
        float dot = h * 0.28f;
        float tw = ui.textWidth(Ui.Font.LABEL, label);
        float w = pad + dot + 6f + tw + pad;
        ui.rect(x, y, w, h, Theme.SURFACE_CONTAINER_HIGH, h * 0.5f, 1f, Theme.OUTLINE_VARIANT.alpha(0.5f), 0f);
        float dy = y + (h - dot) * 0.5f;
        ui.rect(x + pad, dy, dot, dot, statusColor, dot * 0.5f);
        ui.textLeft(Ui.Font.LABEL, label, x + pad + dot + 6f, y + h * 0.5f, Theme.ON_SURFACE);
    }

    public void tooltip(float x, float y, String message) {
        if (message == null || message.isEmpty()) {
            return;
        }
        float padX = 10f;
        float padY = 6f;
        float tw = ui.textWidth(Ui.Font.LABEL, message);
        float bw = tw + padX * 2f;
        float bh = Ui.Font.LABEL.size + padY * 2f;
        ui.elevatedShadow(x, y, bw, bh, 6f, 3f);
        ui.rect(x, y, bw, bh, Theme.INVERSE_SURFACE, 6f);
        ui.textLeft(Ui.Font.LABEL, message, x + padX, y + bh * 0.5f, Theme.INVERSE_ON_SURFACE);
    }

}

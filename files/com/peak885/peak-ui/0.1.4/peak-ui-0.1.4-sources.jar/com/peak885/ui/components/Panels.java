package com.peak885.ui.components;

import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class Panels {
    private final Ui ui;

    public Panels(Ui ui) {
        this.ui = ui;
    }

    public Ui.SplitResult splitPane(String id, float x, float y, float w, float h, boolean vertical,
                                 float position, float min, float max) {
        Ui.SplitResult r = new Ui.SplitResult();
        float clamped = Math.max(min, Math.min(max, position));
        float dividerThickness = 4f;

        float hx, hy, hw, hh;
        if (vertical) {
            hx = x + clamped - dividerThickness * 0.5f;
            hy = y;
            hw = dividerThickness;
            hh = h;
        } else {
            hx = x;
            hy = y + clamped - dividerThickness * 0.5f;
            hw = w;
            hh = dividerThickness;
        }

        Ui.DragResult d = ui.dragZone(id, hx, hy, hw, hh);
        if (d.dragging) {
            clamped = Math.max(min, Math.min(max, clamped + (vertical ? d.dx : d.dy)));
        }
        r.position = clamped;
        r.dragging = d.dragging;

        Rgba color = d.dragging ? Theme.PRIMARY.alpha(0.6f) : Theme.OUTLINE_VARIANT.alpha(0.5f);
        if (vertical) {
            ui.rect(x + clamped - 1f, y, 2f, h, color, 0f);
        } else {
            ui.rect(x, y + clamped - 1f, w, 2f, color, 0f);
        }
        return r;
    }

    public Ui.ResizeResult resizablePanel(String id, float x, float y, float width, float height,
                                       float minW, float minH, float maxW, float maxH) {
        Ui.ResizeResult r = new Ui.ResizeResult();
        float grip = 14f;
        String handleId = id + "#resize";
        Ui.DragResult d = ui.dragZone(handleId, x + width - grip, y + height - grip, grip, grip);
        float w = width, h = height;
        if (d.dragging) {
            w = Math.max(minW, Math.min(maxW, width + d.dx));
            h = Math.max(minH, Math.min(maxH, height + d.dy));
        }
        r.width = w;
        r.height = h;
        r.resizing = d.dragging;
        // Grip glyph
        Rgba c = Theme.ON_SURFACE_VARIANT.alpha(ui.isDragging(handleId) ? 0.75f : 0.4f);
        for (int i = 0; i < 3; i++) {
            float o = i * 4f;
            ui.rect(x + w - 4f - o, y + h - 2f, 2f, 2f, c, 1f);
            ui.rect(x + w - 2f, y + h - 4f - o, 2f, 2f, c, 1f);
        }
        return r;
    }

    public Ui.TitleBarResult panelTitleBar(String id, float x, float y, float w, float h, String title, boolean closable) {
        Ui.TitleBarResult r = new Ui.TitleBarResult();
        Ui.DragResult d = ui.dragZone(id + "#titlebar", x, y, w - (closable ? h : 0f), h);
        r.dx = d.dx;
        r.dy = d.dy;
        r.dragging = d.dragging;

        ui.rect(x, y, w, h, Theme.SURFACE_CONTAINER_HIGH, 0f);
        ui.textLeft(Ui.Font.LABEL, title, x + 12f, y + h * 0.5f, Theme.ON_SURFACE);

        if (closable) {
            Ui.Interaction close = ui.interact(id + "#close", x + w - h, y, h, h);
            if (close.hovered) {
                ui.rect(x + w - h, y, h, h, Theme.ON_SURFACE.alpha(0.1f), 0f);
            }
            ui.textCentered(Ui.Font.LABEL, "×", x + w - h * 0.5f, y + h * 0.5f, Theme.ON_SURFACE_VARIANT);
            r.closeClicked = close.clicked;
        }
        return r;
    }
}

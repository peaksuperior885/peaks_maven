package com.peak885.ui.components;

import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class Drag {
    private final Ui ui;

    private final java.util.Map<String, float[]> dragLastMouse = new java.util.HashMap<>();
    private final java.util.Map<String, float[]> dragTotals = new java.util.HashMap<>();
    private String activeDragId;
    private Object dragPayload;

    public Drag(Ui ui) {
        this.ui = ui;
    }

    public Ui.DragResult dragZone(String id, float x, float y, float w, float h) {
        Ui.DragResult r = new Ui.DragResult();
        Ui.Interaction in = ui.interact(id, x, y, w, h);
        if (in.hovered) {
            ui.requestCursor(Ui.CURSOR_HAND);
        }
        if (in.hovered && ui.mousePressed && this.activeDragId == null) {
            this.activeDragId = id;
            this.dragLastMouse.put(id, new float[]{ui.mouseX, ui.mouseY});
            this.dragTotals.put(id, new float[]{0f, 0f});
            r.started = true;
        }
        if (id.equals(this.activeDragId) && ui.mouseDown) {
            float[] last = this.dragLastMouse.get(id);
            r.dx = ui.mouseX - last[0];
            r.dy = ui.mouseY - last[1];
            last[0] = ui.mouseX;
            last[1] = ui.mouseY;
            float[] tot = this.dragTotals.get(id);
            tot[0] += r.dx;
            tot[1] += r.dy;
            r.totalDx = tot[0];
            r.totalDy = tot[1];
            r.dragging = true;
        } else if (id.equals(this.activeDragId) && ui.mouseReleased) {
            float[] tot = this.dragTotals.get(id);
            if (tot != null) {
                r.totalDx = tot[0];
                r.totalDy = tot[1];
            }
            r.released = true;
            this.activeDragId = null;
            this.dragPayload = null;
        }
        return r;
    }

    public boolean isDragging(String id) {
        return id != null && id.equals(this.activeDragId);
    }

    public String activeDragId() {
        return this.activeDragId;
    }

    public void setDragPayload(Object payload) {
        this.dragPayload = payload;
    }

    public Object dragPayload() {
        return this.dragPayload;
    }

    public Ui.PanelDragResult draggablePanel(String id, float x, float y,
                                          float handleX, float handleY, float handleW, float handleH) {
        Ui.PanelDragResult r = new Ui.PanelDragResult();
        Ui.DragResult d = this.dragZone(id + "#handle", handleX, handleY, handleW, handleH);
        r.x = x + d.dx;
        r.y = y + d.dy;
        r.dragging = d.dragging;
        return r;
    }

    public Ui.ReorderResult reorderableList(String id, float x, float y, float w, float rowH, String[] labels, int[] order) {
        int n = labels.length;
        int[] ord = (order != null && order.length == n) ? order.clone() : identityOrder(n);
        Ui.ReorderResult result = new Ui.ReorderResult();
        result.order = ord;

        int draggingSlot = -1;
        float dragDy = 0f;
        String draggingRowId = null;
        for (int slot = 0; slot < n; slot++) {
            if (this.isDragging(id + "#row" + ord[slot])) {
                draggingSlot = slot;
                draggingRowId = id + "#row" + ord[slot];
            }
        }

        for (int slot = 0; slot < n; slot++) {
            int original = ord[slot];
            String rowId = id + "#row" + original;
            float restY = y + slot * rowH;
            Ui.DragResult d = this.dragZone(rowId, x, restY, w, rowH);
            if (d.dragging) {
                draggingSlot = slot;
                draggingRowId = rowId;
                dragDy = d.totalDy;
            }
        }

        if (draggingSlot >= 0) {
            int shift = Math.round(dragDy / rowH);
            if (shift != 0) {
                int newSlot = Math.max(0, Math.min(n - 1, draggingSlot + shift));
                if (newSlot != draggingSlot) {
                    int moved = ord[draggingSlot];
                    if (newSlot > draggingSlot) {
                        System.arraycopy(ord, draggingSlot + 1, ord, draggingSlot, newSlot - draggingSlot);
                    } else {
                        System.arraycopy(ord, newSlot, ord, newSlot + 1, draggingSlot - newSlot);
                    }
                    ord[newSlot] = moved;
                    result.changed = true;
                    float[] tot = this.dragTotals.get(draggingRowId);
                    if (tot != null) {
                        tot[1] -= shift * rowH;
                        dragDy = tot[1];
                    }
                    draggingSlot = newSlot;
                }
            }
        }
        result.order = ord;
        result.draggingSlot = draggingSlot;

        for (int slot = 0; slot < n; slot++) {
            int original = ord[slot];
            boolean isDraggingRow = (slot == draggingSlot);
            float restY = y + slot * rowH;
            float drawY = isDraggingRow ? restY + dragDy : ui.anim(id + "#row" + original + "#y", restY, 26f);
            if (isDraggingRow) {
                ui.setLayer(ui.layer() + 1);
                ui.elevatedShadow(x, drawY, w, rowH - 4f, 8f, 6f);
            }
            ui.rect(x, drawY, w, rowH - 4f, isDraggingRow ? Theme.SURFACE_CONTAINER_HIGH : Theme.SURFACE_CONTAINER,
                    8f, isDraggingRow ? 1f : 0f, Theme.PRIMARY.alpha(0.6f), 0f);
            ui.textLeft(Ui.Font.BODY, labels[original], x + 14f, drawY + (rowH - 4f) * 0.5f, Theme.ON_SURFACE);
            // simple grip glyph
            ui.textLeft(Ui.Font.LABEL, "⋮⋮", x + w - 28f, drawY + (rowH - 4f) * 0.5f, Theme.ON_SURFACE_VARIANT.alpha(0.6f));
            if (isDraggingRow) {
                ui.setLayer(ui.layer() - 1);
            }
        }
        return result;
    }

    private static int[] identityOrder(int n) {
        int[] o = new int[n];
        for (int i = 0; i < n; i++) o[i] = i;
        return o;
    }
}

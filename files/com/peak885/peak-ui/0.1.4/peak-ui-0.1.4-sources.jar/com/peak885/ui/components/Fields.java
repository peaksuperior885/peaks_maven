package com.peak885.ui.components;

import com.peak885.ui.Box;
import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Text fields, toggles, checkboxes, sliders, segmented controls.
 */
public final class Fields {
    private final Ui ui;

    public Fields(Ui ui) {
        this.ui = ui;
    }

    public Ui.TextFieldResult textField(String id, float x, float y, float w, float h,
                                     String value, String placeholder) {
        return textField(id, x, y, w, h, value, placeholder, 0);
    }

    public Ui.TextFieldResult textField(String id, float x, float y, float w, float h,
                                     String value, String placeholder, int maxLength) {
        return textFieldInternal(id, x, y, w, h, value, placeholder, maxLength, false);
    }

    public Ui.TextFieldResult searchField(String id, float x, float y, float w, float h,
                                       String value, String placeholder) {
        return textFieldInternal(id, x, y, w, h, value != null ? value : "",
                placeholder != null ? placeholder : "Search", 0, true);
    }

    private Ui.TextFieldResult textFieldInternal(String id, float x, float y, float w, float h,
                                              String value, String placeholder, int maxLength,
                                              boolean searchStyle) {
        Ui.TextFieldResult r = new Ui.TextFieldResult();
        String text = value != null ? value : "";
        r.text = text;

        float radius = searchStyle ? h * 0.5f : 8f;
        float padL = searchStyle ? h * 0.55f + 8f : 14f;
        float padR = searchStyle ? (text.isEmpty() ? 14f : h * 0.55f + 8f) : 14f;

        Ui.Interaction in = ui.interact(id, x, y, w, h);
        r.interaction = in;
        if (in.hovered) {
            ui.requestCursor(Ui.CURSOR_IBEAM);
        }

        if (in.clicked) {
            ui.setFocusedId(id);
        } else if (ui.mousePressed && !in.hovered && ui.isFocused(id)) {
            ui.setFocusedId(null);
        }
        if (ui.escapePressed && ui.isFocused(id)) {
            ui.setFocusedId(null);
        }
        boolean focused = ui.isFocused(id);
        r.focused = focused;

        // Consume keyboard input only when focused
        if (focused) {
            if (ui.backspaces > 0 && !text.isEmpty()) {
                int n = Math.min(ui.backspaces, text.length());
                text = text.substring(0, text.length() - n);
                r.changed = true;
            }
            if (ui.typed.length() > 0) {
                StringBuilder sb = new StringBuilder(text);
                for (int i = 0; i < ui.typed.length(); i++) {
                    char c = ui.typed.charAt(i);
                    if (c == '\n' || c == '\r') {
                        r.submitted = true;
                        continue;
                    }
                    if (c >= 32) {
                        if (maxLength <= 0 || sb.length() < maxLength) {
                            sb.append(c);
                            r.changed = true;
                        }
                    }
                }
                text = sb.toString();
            }
            r.text = text;
        }

        float focusAmt = ui.anim(id + "#focus", focused ? 1f : 0f, 22f);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 20f);

        Rgba fill = Theme.SURFACE_CONTAINER_HIGHEST.mix(Theme.SURFACE_CONTAINER_HIGH, hover * 0.3f);
        Rgba border = Theme.OUTLINE_VARIANT.mix(Theme.PRIMARY, focusAmt);
        float borderW = 1f + focusAmt * 0.75f;

        Box box = ui.boxFor(id);
        box.bounds(x, y, Math.max(0f, w), Math.max(0f, h))
                .cornerRadius(radius)
                .color(fill)
                .border(borderW, border)
                .softness(0f);
        ui.enqueueBox(box);

        if (searchStyle) {
            float cx = x + h * 0.38f;
            float cy = y + h * 0.5f;
            float rIcon = h * 0.14f;
            ui.rect(cx - rIcon, cy - rIcon, rIcon * 2f, rIcon * 2f,
                    Theme.ON_SURFACE_VARIANT.alpha(0.55f), rIcon,
                    1.5f, Theme.ON_SURFACE_VARIANT.alpha(0.75f), 0f);
            float hx = cx + rIcon * 0.55f;
            float hy = cy + rIcon * 0.55f;
            ui.rect(hx, hy, h * 0.12f, 1.6f, Theme.ON_SURFACE_VARIANT.alpha(0.75f), 1f);
        }

        if (searchStyle && !text.isEmpty()) {
            float clearSize = h * 0.45f;
            float cx = x + w - h * 0.5f;
            float cy = y + h * 0.5f;
            Ui.Interaction clear = ui.interact(id + "#clear", cx - clearSize * 0.5f, cy - clearSize * 0.5f,
                    clearSize, clearSize);
            if (clear.hovered) {
                ui.requestCursor(Ui.CURSOR_HAND);
            }
            ui.rect(cx - clearSize * 0.35f, cy - clearSize * 0.35f, clearSize * 0.7f, clearSize * 0.7f,
                    Theme.ON_SURFACE_VARIANT.alpha(clear.hovered ? 0.25f : 0.12f), clearSize * 0.35f);
            ui.textCentered(Ui.Font.LABEL, "×", cx, cy, Theme.ON_SURFACE_VARIANT);
            if (clear.clicked) {
                text = "";
                r.text = text;
                r.changed = true;
                ui.setFocusedId(id);
            }
        }

        float textX = x + padL;
        float textMaxW = w - padL - padR;
        ui.pushClip(textX, y, textMaxW, h);
        if (text.isEmpty() && !focused) {
            String ph = placeholder != null ? placeholder : "";
            ui.textLeft(Ui.Font.BODY, ui.fit(Ui.Font.BODY, ph, (int) textMaxW), textX, y + h * 0.5f,
                    Theme.ON_SURFACE_VARIANT.alpha(0.65f));
        } else {
            String display = ui.fit(Ui.Font.BODY, text, (int) textMaxW);
            if (ui.textWidth(Ui.Font.BODY, text) > textMaxW) {
                display = text;
                while (display.length() > 1 && ui.textWidth(Ui.Font.BODY, display) > textMaxW) {
                    display = display.substring(1);
                }
            }
            ui.textLeft(Ui.Font.BODY, display, textX, y + h * 0.5f, Theme.ON_SURFACE);

            if (focused) {
                float caretOn = ((int) (ui.time * 2.0) % 2 == 0) ? 1f : 0f;
                if (caretOn > 0f) {
                    float cw = ui.textWidth(Ui.Font.BODY, display);
                    ui.rect(textX + cw + 1f, y + h * 0.25f, 1.5f, h * 0.5f, Theme.PRIMARY, 0f);
                }
            }
        }
        ui.popClip();

        return r;
    }

    public boolean toggle(String id, float x, float y, float height, boolean on) {
        float h = Math.max(20f, height);
        float w = h * 1.7f;
        Ui.Interaction in = ui.interact(id, x, y, w, h);
        if (in.clicked) {
            on = !on;
        }
        float t = ui.anim(id + "#on", on ? 1f : 0f, 18f);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 20f);

        Rgba trackOff = Theme.SURFACE_CONTAINER_HIGHEST.mix(Theme.OUTLINE, 0.35f);
        Rgba trackOn = Theme.PRIMARY;
        Rgba track = trackOff.mix(trackOn, t);
        float trackR = h * 0.5f;
        ui.rect(x, y, w, h, track.mix(Theme.ON_SURFACE, hover * 0.06f), trackR);

        float thumbPad = h * 0.12f;
        float thumbD = h - 2f * thumbPad;
        float thumbX = x + thumbPad + t * (w - thumbD - 2f * thumbPad);
        float thumbY = y + thumbPad;
        // Soft shadow under thumb
        ui.rect(thumbX + 1f, thumbY + 1.5f, thumbD, thumbD, new Rgba(0f, 0f, 0f, 0.18f), thumbD * 0.5f);
        ui.rect(thumbX, thumbY, thumbD, thumbD, Theme.ON_PRIMARY.mix(Theme.ON_SURFACE, 1f - t * 0.15f), thumbD * 0.5f);
        return on;
    }

    public boolean checkbox(String id, float x, float y, float size, boolean checked) {
        float s = Math.max(14f, size);
        Ui.Interaction in = ui.interact(id, x, y, s, s);
        if (in.clicked) {
            checked = !checked;
        }
        float t = ui.anim(id + "#chk", checked ? 1f : 0f, 20f);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 20f);

        Rgba fill = Theme.SURFACE_CONTAINER_HIGH.mix(Theme.PRIMARY, t);
        Rgba border = Theme.OUTLINE.mix(Theme.PRIMARY, Math.max(t, hover * 0.5f));
        ui.rect(x, y, s, s, fill, 4f, 1.5f, border, 0f);

        if (t > 0.05f) {
            float a = Math.min(1f, t * 1.4f);
            Rgba mark = Theme.ON_PRIMARY.alpha(a);
            float cx = x + s * 0.28f;
            float cy = y + s * 0.55f;
            ui.rect(cx, cy, s * 0.18f, 2f, mark, 1f);
            ui.rect(cx + s * 0.12f, cy - s * 0.22f, 2f, s * 0.38f, mark, 1f);
        }
        return checked;
    }

    public float slider(String id, float x, float y, float w, float h, float value, float min, float max) {
        if (max <= min) {
            max = min + 1f;
        }
        float trackH = Math.max(4f, h * 0.22f);
        float thumbR = Math.max(8f, h * 0.42f);
        float trackY = y + (h - trackH) * 0.5f;

        Ui.Interaction in = ui.interact(id, x - thumbR, y, w + 2f * thumbR, h);
        float t = (value - min) / (max - min);
        t = Math.max(0f, Math.min(1f, t));

        if (in.pressed || (in.hovered && ui.mouseDown && id.equals(ui.pressedId()))) {
            float nx = (ui.mouseX - x) / w;
            t = Math.max(0f, Math.min(1f, nx));
            value = min + t * (max - min);
        }

        float animT = ui.anim(id + "#t", t, 28f);
        float drawT = (in.pressed) ? t : animT;

        ui.rect(x, trackY, w, trackH, Theme.SURFACE_CONTAINER_HIGHEST, trackH * 0.5f);
        float filledW = w * drawT;
        if (filledW > 0.5f) {
            ui.rect(x, trackY, filledW, trackH, Theme.PRIMARY, trackH * 0.5f);
        }

        float tx = x + w * drawT;
        float ty = y + h * 0.5f;
        float hover = ui.anim(id + "#hover", in.hovered || in.pressed ? 1f : 0f, 20f);
        if (hover > 0.01f) {
            float ring = thumbR + 4f * hover;
            ui.rect(tx - ring, ty - ring, ring * 2f, ring * 2f, Theme.PRIMARY.alpha(0.12f * hover), ring);
        }
        ui.rect(tx - thumbR + 1f, ty - thumbR + 1.5f, thumbR * 2f, thumbR * 2f,
                new Rgba(0f, 0f, 0f, 0.2f), thumbR);
        ui.rect(tx - thumbR, ty - thumbR, thumbR * 2f, thumbR * 2f, Theme.PRIMARY, thumbR);
        return value;
    }

    public int segmented(String id, float x, float y, float w, float h, String[] labels, int selected) {
        if (labels == null || labels.length == 0) {
            return 0;
        }
        int n = labels.length;
        int sel = Math.floorMod(selected, n);
        float segW = w / n;
        float radius = h * 0.5f;

        ui.rect(x, y, w, h, Theme.SURFACE_CONTAINER_HIGH, radius, 1.25f, Theme.OUTLINE_VARIANT, 0f);

        for (int i = 0; i < n; i++) {
            float sx = x + i * segW;
            String segId = id + "#seg" + i;
            Ui.Interaction in = ui.interact(segId, sx, y, segW, h);
            if (in.clicked) {
                sel = i;
            }
            boolean isSel = (i == sel);
            float hover = ui.anim(segId + "#hover", in.hovered ? 1f : 0f, 20f);

            if (isSel) {
                float inset = 3f;
                ui.rect(sx + inset, y + inset, segW - 2f * inset, h - 2f * inset,
                        Theme.SECONDARY_CONTAINER, radius - inset);
            } else if (hover > 0.01f) {
                ui.rect(sx + 2f, y + 2f, segW - 4f, h - 4f,
                        Theme.ON_SURFACE.alpha(0.06f * hover), radius - 2f);
            }

            Rgba labelC = isSel ? Theme.ON_SECONDARY_CONTAINER : Theme.ON_SURFACE_VARIANT;
            ui.textCentered(Ui.Font.LABEL, labels[i], sx + segW * 0.5f, y + h * 0.5f, labelC);

            if (i < n - 1 && !isSel && sel != i + 1) {
                ui.rect(sx + segW - 0.5f, y + h * 0.25f, 1f, h * 0.5f,
                        Theme.OUTLINE_VARIANT.alpha(0.5f), 0f);
            }
        }
        return sel;
    }
}

package com.peak885.ui.components;

import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class Navigation {
    private final Ui ui;

    private final java.util.Map<String, Boolean> dropdowns = new java.util.HashMap<>();

    public Navigation(Ui ui) {
        this.ui = ui;
    }

    public Ui.TabsResult tabs(String id, float x, float y, float width, float height,
                           String[] labels, int selected) {
        return tabs(id, x, y, width, height, labels, selected,
                Theme.PRIMARY, Theme.ON_SURFACE, Theme.ON_SURFACE_VARIANT);
    }
    public Ui.TabsResult tabs(String id, float x, float y, float width, float height,
                           String[] labels, int selected,
                           Rgba indicatorColor, Rgba selectedLabel, Rgba unselectedLabel) {
        Ui.TabsResult result = new Ui.TabsResult();
        if (labels == null || labels.length == 0) {
            result.selected = 0;
            return result;
        }
        int n = labels.length;
        int sel = Math.floorMod(selected, n);
        float tabW = width / n;
        float indicatorH = 3f;

        ui.rect(x, y + height - 1f, width, 1f, Theme.OUTLINE_VARIANT.alpha(0.45f), 0f);

        int clicked = -1;
        for (int i = 0; i < n; i++) {
            float tx = x + i * tabW;
            String tabId = id + "#tab" + i;
            Ui.Interaction in = ui.interact(tabId, tx, y, tabW, height);
            float hover = ui.anim(tabId + "#hover", in.hovered ? 1f : 0f, 22f);

            if (hover > 0.01f || in.pressed) {
                float amount = 0.08f * hover + (in.pressed ? 0.05f : 0f);
                ui.rect(tx, y, tabW, height, Theme.ON_SURFACE.alpha(amount), 0f);
            }

            boolean isSel = (i == sel);
            Rgba labelColor = isSel
                    ? selectedLabel
                    : unselectedLabel.mix(selectedLabel, hover * 0.35f);
            ui.textCentered(Ui.Font.BODY, labels[i], tx + tabW * 0.5f, y + height * 0.5f, labelColor);

            if (in.clicked) {
                clicked = i;
            }
        }

        if (clicked >= 0 && clicked != sel) {
            sel = clicked;
            result.changed = true;
        }
        result.selected = sel;

        float targetX = x + sel * tabW;
        float targetW = tabW;
        float indX = ui.anim(id + "#indX", targetX, 18f);
        float indW = ui.anim(id + "#indW", targetW, 18f);
        // Slightly inset indicator for a cleaner look
        float inset = Math.min(12f, tabW * 0.12f);
        ui.rect(indX + inset, y + height - indicatorH, Math.max(0f, indW - 2f * inset), indicatorH,
                indicatorColor, indicatorH * 0.5f);

        result.indicatorX = indX;
        result.indicatorW = indW;
        return result;
    }
    public Ui.DropdownResult dropdown(String id, float x, float y, float w, float h,
                                   String[] options, int selected) {
        Ui.DropdownResult result = new Ui.DropdownResult();
        if (options == null || options.length == 0) {
            result.selected = 0;
            return result;
        }
        int sel = Math.max(0, Math.min(selected, options.length - 1));
        boolean expanded = this.dropdowns.getOrDefault(id, false);
        Ui.Interaction anchor = ui.interact(id + "#anchor", x, y, w, h);
        if (anchor.clicked) expanded = !expanded;
        if (ui.escapePressed && expanded) expanded = false;

        float menuY = y + h + 4f;
        float rowH = Math.max(40f, h);
        float menuH = rowH * options.length;
        if (menuY + menuH > ui.height && y >= menuH + 4f) menuY = y - menuH - 4f;
        if (expanded && ui.mousePressed && !ui.hit(x, y, w, h)
                && !ui.hit(x, menuY, w, menuH)) expanded = false;

        ui.surface(id + "#anchor", x, y, w, h, 10f,
                Theme.SURFACE_CONTAINER_HIGH, Theme.ON_SURFACE);
        ui.rect(x, y, w, h, Theme.SURFACE_CONTAINER_HIGH, 10f,
                1f, expanded ? Theme.PRIMARY : Theme.OUTLINE, 0f);
        ui.textLeft(Ui.Font.BODY, ui.fit(Ui.Font.BODY, options[sel], Math.max(0, (int) w - 48)),
                x + 14, y + h * 0.5f, Theme.ON_SURFACE);
        float cx = x + w - 20;
        float cy = y + h * 0.5f;
        ui.textCentered(Ui.Font.BODY, expanded ? "⌃" : "⌄", cx, cy, Theme.ON_SURFACE_VARIANT);

        if (expanded) {
            ui.setLayer(ui.layer() + 1);
            ui.elevatedShadow(x, menuY, w, menuH, 8f, 4f);
            ui.rect(x, menuY, w, menuH, Theme.SURFACE_CONTAINER, 8f,
                    1f, Theme.OUTLINE_VARIANT.alpha(0.65f), 0f);
            for (int i = 0; i < options.length; i++) {
                float oy = menuY + i * rowH;
                Ui.Interaction option = ui.interact(id + "#option" + i, x + 4, oy + 2, w - 8, rowH - 4);
                if (i == sel) ui.rect(x + 4, oy + 2, w - 8, rowH - 4, Theme.SECONDARY_CONTAINER, 6f);
                else if (option.hovered) ui.rect(x + 4, oy + 2, w - 8, rowH - 4,
                        Theme.ON_SURFACE.alpha(0.08f), 6f);
                ui.textLeft(Ui.Font.BODY, ui.fit(Ui.Font.BODY, options[i], Math.max(0, (int) w - 32)),
                        x + 16, oy + rowH * 0.5f,
                        i == sel ? Theme.ON_SECONDARY_CONTAINER : Theme.ON_SURFACE);
                if (option.clicked) {
                    sel = i;
                    result.changed = sel != selected;
                    expanded = false;
                }
            }
            ui.setLayer(ui.layer() - 1);
        }
        this.dropdowns.put(id, expanded);
        result.selected = sel;
        result.expanded = expanded;
        return result;
    }

    public Ui.TabsResult tabsAuto(String id, float x, float y, float maxWidth, float height,
                               String[] labels, int selected) {
        Ui.TabsResult result = new Ui.TabsResult();
        if (labels == null || labels.length == 0) {
            result.selected = 0;
            return result;
        }
        int n = labels.length;
        int sel = Math.floorMod(selected, n);
        float hPad = 16f;
        float gap = 4f;

        float[] widths = new float[n];
        float total = 0f;
        for (int i = 0; i < n; i++) {
            widths[i] = ui.textWidth(Ui.Font.BODY, labels[i]) + 2f * hPad;
            total += widths[i];
            if (i > 0) total += gap;
        }
        float rowW = Math.min(maxWidth, total);

        ui.rect(x, y + height - 1f, rowW, 1f, Theme.OUTLINE_VARIANT.alpha(0.45f), 0f);

        float cursor = x;
        float[] lefts = new float[n];
        int clicked = -1;
        for (int i = 0; i < n; i++) {
            lefts[i] = cursor;
            float tw = widths[i];
            String tabId = id + "#tab" + i;
            Ui.Interaction in = ui.interact(tabId, cursor, y, tw, height);
            float hover = ui.anim(tabId + "#hover", in.hovered ? 1f : 0f, 22f);
            if (hover > 0.01f || in.pressed) {
                float amount = 0.08f * hover + (in.pressed ? 0.05f : 0f);
                ui.rect(cursor, y, tw, height, Theme.ON_SURFACE.alpha(amount), 8f);
            }
            boolean isSel = (i == sel);
            Rgba labelColor = isSel
                    ? Theme.PRIMARY
                    : Theme.ON_SURFACE_VARIANT.mix(Theme.PRIMARY, hover * 0.35f);
            ui.textCentered(Ui.Font.BODY, labels[i], cursor + tw * 0.5f, y + height * 0.5f, labelColor);
            if (in.clicked) {
                clicked = i;
            }
            cursor += tw + gap;
        }

        if (clicked >= 0 && clicked != sel) {
            sel = clicked;
            result.changed = true;
        }
        result.selected = sel;

        float targetX = lefts[sel];
        float targetW = widths[sel];
        float indX = ui.anim(id + "#indX", targetX, 18f);
        float indW = ui.anim(id + "#indW", targetW, 18f);
        float inset = 6f;
        ui.rect(indX + inset, y + height - 3f, Math.max(0f, indW - 2f * inset), 3f,
                Theme.PRIMARY, 1.5f);

        result.indicatorX = indX;
        result.indicatorW = indW;
        return result;
    }
}

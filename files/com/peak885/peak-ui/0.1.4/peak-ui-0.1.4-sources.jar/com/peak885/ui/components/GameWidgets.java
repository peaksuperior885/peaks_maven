package com.peak885.ui.components;

import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class GameWidgets {
    private final Ui ui;

    public GameWidgets(Ui ui) {
        this.ui = ui;
    }

    public Ui.Interaction proximityPrompt(String id, float centerX, float centerY,
                                       String key, String action, float visibility) {
        float vis = Math.max(0f, Math.min(1f, visibility));
        float a = ui.anim(id + "#prox", vis, 16f);
        if (a < 0.02f) {
            Ui.Interaction empty = new Ui.Interaction();
            return empty;
        }

        String k = key == null ? "?" : key;
        String act = action == null ? "" : action;

        float keyPadX = 8f;
        float gap = 10f;
        float sidePad = 12f;
        float h = 34f;
        float keyTw = ui.textWidth(Ui.Font.LABEL, k);
        float actTw = act.isEmpty() ? 0 : ui.textWidth(Ui.Font.BODY, act);
        float keyW = Math.max(h - 8f, keyTw + keyPadX * 2f);
        float totalW = sidePad + keyW + (act.isEmpty() ? 0 : gap + actTw) + sidePad;

        float scale = 0.88f + 0.12f * a;
        float bob = (float) Math.sin(ui.time * 2.6) * 2.2f * a;
        float w = totalW * scale;
        float hh = h * scale;
        float x = centerX - w * 0.5f;
        float y = centerY - hh * 0.5f + bob - 8f;

        Ui.Interaction in = ui.interact(id, x, y, w, hh);

        ui.rect(x + 2f, y + 3f, w, hh, new Rgba(0f, 0f, 0f, 0.35f * a), hh * 0.5f, 0f, null, 6f);

        Rgba body = Theme.SURFACE_CONTAINER_HIGH.alpha(0.92f * a);
        Rgba border = Theme.GLASS_BORDER.alpha(0.55f * a);
        ui.rect(x, y, w, hh, body, hh * 0.5f, 1.25f, border, 0f);

        float badgeH = hh - 10f * scale;
        float badgeX = x + sidePad * scale;
        float badgeY = y + (hh - badgeH) * 0.5f;
        float badgeW = keyW * scale;
        Rgba badgeBg = Theme.PRIMARY_CONTAINER.alpha(0.95f * a);
        Rgba badgeBorder = Theme.PRIMARY.alpha(0.45f * a);
        ui.rect(badgeX, badgeY, badgeW, badgeH, badgeBg, 7f * scale, 1f, badgeBorder, 0f);
        ui.textCentered(Ui.Font.LABEL, k, badgeX + badgeW * 0.5f, badgeY + badgeH * 0.5f,
                Theme.ON_PRIMARY_CONTAINER.alpha(a));

        if (!act.isEmpty()) {
            float textX = badgeX + badgeW + gap * scale;
            ui.textLeft(Ui.Font.BODY, act, textX, y + hh * 0.5f, Theme.ON_SURFACE.alpha(a));
        }

        return in;
    }

    public Ui.Interaction proximityPrompt(String id, float centerX, float centerY,
                                       String key, String action) {
        return proximityPrompt(id, centerX, centerY, key, action, 1f);
    }
}

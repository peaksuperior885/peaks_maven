package com.peak885.ui.components;

import com.peak885.ui.Box;
import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class Surfaces {
    private final Ui ui;

    public Surfaces(Ui ui) {
        this.ui = ui;
    }

    public void card(float x, float y, float w, float h, float radius, float elevation, Rgba fill) {
        if (elevation > 0f) {
            ui.elevatedShadow(x, y, w, h, radius, elevation);
        }
        ui.rect(x, y, w, h, fill, radius);
    }

    public void outlinedCard(float x, float y, float w, float h, float radius, Rgba fill, Rgba outline) {
        ui.rect(x, y, w, h, fill, radius, 1.25f, outline, 0f);
    }

    public void glass(float x, float y, float w, float h, float radius) {
        glass(x, y, w, h, radius, Theme.GLASS, Theme.GLASS_BORDER, 10f);
    }

    public void glass(float x, float y, float w, float h, float radius,
                      Rgba fill, Rgba border, float softness) {
        ui.rect(x, y, w, h, fill, radius, 1.0f, border != null ? border : Theme.GLASS_BORDER, softness);
    }

    public Ui.Interaction glassSurface(String id, float x, float y, float w, float h, float radius) {
        return glassSurface(id, x, y, w, h, radius, Theme.GLASS, Theme.GLASS_BORDER, 10f);
    }

    public Ui.Interaction glassSurface(String id, float x, float y, float w, float h, float radius,
                                    Rgba base, Rgba border, float softness) {
        Ui.Interaction in = ui.interact(id, x, y, w, h);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 18f);
        Box box = ui.boxFor(id);
        if (in.hovered && ui.mousePressed) {
            box.press(ui.mouseX - x, ui.mouseY - y, ui.time);
        }
        float amount = 0.10f * hover + (in.pressed ? 0.06f : 0f);
        Rgba tinted = base.mix(Theme.ON_SURFACE, amount * 0.35f);
        float a = Math.min(1f, tinted.a + 0.08f * hover);
        box.bounds(x, y, Math.max(0f, w), Math.max(0f, h))
                .cornerRadius(radius)
                .color(new Rgba(tinted.r, tinted.g, tinted.b, a))
                .border(1.15f, border != null ? border : Theme.GLASS_BORDER)
                .softness(softness);
        ui.enqueueBox(box);
        return in;
    }

    public void divider(float x, float y, float w) {
        ui.rect(x, y, w, 1f, Theme.OUTLINE_VARIANT.alpha(0.55f), 0f);
    }

    public void elevatedShadow(float x, float y, float w, float h, float radius, float elevation) {
        float e = Math.max(0f, Math.min(24f, elevation));
        int layers = 1 + (int) (e / 4f);
        for (int i = 1; i <= layers; i++) {
            float t = i / (float) layers;
            float s = e * 0.35f * t;
            float oy = e * 0.22f * t;
            float a = 0.04f * (1f - t * 0.65f);
            ui.rect(x - s, y - s + oy, w + 2 * s, h + 2 * s, new Rgba(0f, 0f, 0f, a), radius + s * 0.4f);
        }
    }

    public Ui.Interaction chip(String id, float x, float y, float w, float h, boolean selected) {
        float radius = h * 0.5f;
        Rgba base = selected ? Theme.SECONDARY_CONTAINER : Theme.SURFACE_CONTAINER_HIGH;
        Rgba border = selected ? Theme.SECONDARY_CONTAINER : Theme.OUTLINE_VARIANT;
        Ui.Interaction in = ui.interact(id, x, y, w, h);
        float hover = ui.anim(id + "#hover", in.hovered ? 1f : 0f, 20f);
        Box box = ui.boxFor(id);
        if (in.hovered && ui.mousePressed) {
            box.press(ui.mouseX - x, ui.mouseY - y, ui.time);
        }
        float amount = 0.08f * hover + (in.pressed ? 0.04f : 0f);
        box.bounds(x, y, Math.max(0f, w), Math.max(0f, h))
                .cornerRadius(radius)
                .color(base.mix(Theme.ON_SURFACE, amount))
                .border(selected ? 0f : 1f, border);
        ui.enqueueBox(box);
        return in;
    }
}

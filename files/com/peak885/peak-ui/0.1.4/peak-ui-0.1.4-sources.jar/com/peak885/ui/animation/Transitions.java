package com.peak885.ui.animation;

public final class Transitions {
    private Transitions() {
    }

    public static Tween fadeIn() {
        return Tween.of(0f, 1f, 0.22f, Easing.EASE_OUT_CUBIC);
    }

    public static Tween fadeOut() {
        return Tween.of(1f, 0f, 0.16f, Easing.EASE_IN_CUBIC);
    }

    public static Tween slideIn(float durationSeconds) {
        return Tween.of(0f, 1f, durationSeconds, Easing.EMPHASIZED_DECELERATE);
    }

    public static Tween slideOut(float durationSeconds) {
        return Tween.of(1f, 0f, durationSeconds, Easing.EMPHASIZED_ACCELERATE);
    }

    public static Tween scaleIn() {
        return Tween.of(0.86f, 1f, 0.18f, Easing.EMPHASIZED_DECELERATE);
    }

    public static Spring springPop() {
        return Spring.snappy(0.86f, 1f);
    }

    public static Spring springSettle(float from, float to) {
        return Spring.soft(from, to);
    }
}

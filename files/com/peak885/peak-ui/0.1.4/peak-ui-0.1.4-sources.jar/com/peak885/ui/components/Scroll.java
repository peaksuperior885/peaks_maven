package com.peak885.ui.components;

import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class Scroll {
    private final Ui ui;

    private static final class ScrollFrame {
        String id;
        float x, y, w, h;
        float offsetX, offsetY;
        float maxOffsetX, maxOffsetY;
    }

    private final java.util.Map<String, float[]> scrollTargets = new java.util.HashMap<>();
    private final java.util.ArrayDeque<ScrollFrame> scrollStack = new java.util.ArrayDeque<>();
    private final java.util.Map<String, float[]> dragLastMouse = new java.util.HashMap<>();

    public Scroll(Ui ui) {
        this.ui = ui;
    }

    public Ui.ScrollResult beginScroll(String id, float x, float y, float w, float h,
                                    float contentWidth, float contentHeight) {
        float maxX = Math.max(0f, contentWidth - w);
        float maxY = Math.max(0f, contentHeight - h);
        float[] target = this.scrollTargets.computeIfAbsent(id, k -> new float[2]);
        target[0] = Math.max(0f, Math.min(maxX, target[0]));
        target[1] = Math.max(0f, Math.min(maxY, target[1]));

        if (maxY > 0f && ui.scrollY != 0f && ui.hit(x, y, w, h)) {
            target[1] = Math.max(0f, Math.min(maxY, target[1] - ui.scrollY * 48f));
        }

        float smoothX = ui.anim(id + "#scrollX", target[0], 28f);
        float smoothY = ui.anim(id + "#ui.scrollY", target[1], 28f);

        ScrollFrame frame = new ScrollFrame();
        frame.id = id;
        frame.x = x;
        frame.y = y;
        frame.w = w;
        frame.h = h;
        frame.offsetX = smoothX;
        frame.offsetY = smoothY;
        frame.maxOffsetX = maxX;
        frame.maxOffsetY = maxY;
        this.scrollStack.push(frame);

        ui.pushClip(x, y, w, h);

        Ui.ScrollResult r = new Ui.ScrollResult();
        r.offsetX = smoothX;
        r.offsetY = smoothY;
        r.maxOffsetX = maxX;
        r.maxOffsetY = maxY;
        r.canScrollX = maxX > 0.5f;
        r.canScrollY = maxY > 0.5f;
        return r;
    }

    public void endScroll() {
        ScrollFrame f = this.scrollStack.pop();
        ui.popClip();

        float[] target = this.scrollTargets.get(f.id);
        float barThickness = 6f;

        if (f.maxOffsetY > 0.5f) {
            float trackX = f.x + f.w - barThickness - 2f;
            float trackY = f.y + 2f;
            float trackH = f.h - 4f - (f.maxOffsetX > 0.5f ? barThickness + 2f : 0f);
            float thumbH = Math.max(24f, trackH * (f.h / (f.h + f.maxOffsetY)));
            float thumbY = trackY + (trackH - thumbH) * (f.offsetY / f.maxOffsetY);
            String thumbId = f.id + "#vthumb";
            Ui.Interaction thumb = ui.interact(thumbId, trackX, thumbY, barThickness, thumbH);
            boolean dragging = thumb.pressed;
            if (dragging && trackH > thumbH) {
                float[] last = this.dragLastMouse.computeIfAbsent(thumbId, k -> new float[]{ui.mouseY, ui.mouseY});
                float dMouse = ui.mouseY - last[0];
                last[0] = ui.mouseY;
                float frac = dMouse / (trackH - thumbH);
                target[1] = Math.max(0f, Math.min(f.maxOffsetY, target[1] + frac * f.maxOffsetY));
            } else {
                this.dragLastMouse.remove(thumbId);
            }
            Rgba track = Theme.ON_SURFACE.alpha(0.06f);
            Rgba thumbColor = Theme.ON_SURFACE.alpha(thumb.hovered || dragging ? 0.42f : 0.26f);
            ui.rect(trackX, trackY, barThickness, trackH, track, barThickness * 0.5f);
            ui.rect(trackX, thumbY, barThickness, thumbH, thumbColor, barThickness * 0.5f);
        }

        if (f.maxOffsetX > 0.5f) {
            float trackY = f.y + f.h - barThickness - 2f;
            float trackX = f.x + 2f;
            float trackW = f.w - 4f - (f.maxOffsetY > 0.5f ? barThickness + 2f : 0f);
            float thumbW = Math.max(24f, trackW * (f.w / (f.w + f.maxOffsetX)));
            float thumbX = trackX + (trackW - thumbW) * (f.offsetX / f.maxOffsetX);
            String thumbId = f.id + "#hthumb";
            Ui.Interaction thumb = ui.interact(thumbId, thumbX, trackY, thumbW, barThickness);
            boolean dragging = thumb.pressed;
            if (dragging && trackW > thumbW) {
                float[] last = this.dragLastMouse.computeIfAbsent(thumbId, k -> new float[]{ui.mouseX, ui.mouseX});
                float dMouse = ui.mouseX - last[0];
                last[0] = ui.mouseX;
                float frac = dMouse / (trackW - thumbW);
                target[0] = Math.max(0f, Math.min(f.maxOffsetX, target[0] + frac * f.maxOffsetX));
            } else {
                this.dragLastMouse.remove(thumbId);
            }
            Rgba track = Theme.ON_SURFACE.alpha(0.06f);
            Rgba thumbColor = Theme.ON_SURFACE.alpha(thumb.hovered || dragging ? 0.42f : 0.26f);
            ui.rect(trackX, trackY, trackW, barThickness, track, barThickness * 0.5f);
            ui.rect(thumbX, trackY, thumbW, barThickness, thumbColor, barThickness * 0.5f);
        }
    }

    public Ui.VirtualRange virtualRange(float scrollOffset, float viewportHeight, float rowHeight, int itemCount) {
        Ui.VirtualRange r = new Ui.VirtualRange();
        if (itemCount <= 0 || rowHeight <= 0f) {
            r.firstIndex = 0;
            r.lastIndexExclusive = 0;
            return r;
        }
        int first = (int) Math.floor(scrollOffset / rowHeight) - 1;
        int visibleCount = (int) Math.ceil(viewportHeight / rowHeight) + 2;
        r.firstIndex = Math.max(0, first);
        r.lastIndexExclusive = Math.min(itemCount, r.firstIndex + visibleCount);
        return r;
    }
}

package com.peak885.ui.components;

import com.peak885.ui.Rgba;
import com.peak885.ui.Theme;
import com.peak885.ui.Ui;

/**
 * Extracted UI components. Called through Ui facade methods so the public API stays stable.
 */
public final class Menus {
    private final Ui ui;

    private String openContextMenuId;
    private float contextMenuX, contextMenuY;

    public Menus(Ui ui) {
        this.ui = ui;
    }

    public void openContextMenu(String id, float atX, float atY) {
        this.openContextMenuId = id;
        this.contextMenuX = atX;
        this.contextMenuY = atY;
    }

    public boolean isContextMenuOpen(String id) {
        return id.equals(this.openContextMenuId);
    }

    public void closeContextMenu() {
        this.openContextMenuId = null;
    }

    public Ui.MenuItem contextMenu(String id, Ui.MenuItem[] items) {
        if (!id.equals(this.openContextMenuId) || items == null || items.length == 0) {
            return null;
        }
        ui.setLayer(ui.maxLayer() + 1);
        Ui.MenuItem clicked = drawMenu(id, items, this.contextMenuX, this.contextMenuY);
        boolean clickedOutside = ui.mousePressed && !menuHitAny(id, items, this.contextMenuX, this.contextMenuY);
        if (ui.escapePressed || clickedOutside || clicked != null) {
            closeContextMenu();
        }
        ui.setLayer(Math.max(0, ui.layer()));
        return clicked;
    }

    private Ui.MenuItem drawMenu(String pathId, Ui.MenuItem[] items, float x, float y) {
        float rowH = 32f;
        float pad = 10f;
        float width = 160f;
        for (Ui.MenuItem it : items) {
            if (it.label != null) {
                width = Math.max(width, ui.textWidth(Ui.Font.BODY, it.label) + pad * 2f + (it.hasChildren() ? 24f : 0f));
            }
        }
        float menuH = 0f;
        for (Ui.MenuItem it : items) menuH += it.isSeparator() ? 9f : rowH;
        if (x + width > ui.width) x = Math.max(0f, x - width);
        if (y + menuH > ui.height) y = Math.max(0f, y - menuH);

        ui.elevatedShadow(x, y, width, menuH, 8f, 6f);
        ui.rect(x, y, width, menuH, Theme.SURFACE_CONTAINER, 8f, 1f, Theme.OUTLINE_VARIANT.alpha(0.6f), 0f);

        Ui.MenuItem result = null;
        float cy = y;
        for (int i = 0; i < items.length; i++) {
            Ui.MenuItem it = items[i];
            if (it.isSeparator()) {
                ui.rect(x + 8f, cy + 4f, width - 16f, 1f, Theme.OUTLINE_VARIANT.alpha(0.5f), 0f);
                cy += 9f;
                continue;
            }
            String itemId = pathId + "#item" + i;
            Ui.Interaction in = it.enabled ? ui.interact(itemId, x, cy, width, rowH) : new Ui.Interaction();
            if (in.hovered) {
                ui.rect(x + 4f, cy + 2f, width - 8f, rowH - 4f, Theme.ON_SURFACE.alpha(0.08f), 6f);
            }
            Rgba color = it.enabled ? Theme.ON_SURFACE : Theme.ON_SURFACE.alpha(0.38f);
            ui.textLeft(Ui.Font.BODY, it.label, x + pad, cy + rowH * 0.5f, color);
            if (it.hasChildren()) {
                ui.textLeft(Ui.Font.LABEL, "›", x + width - 18f, cy + rowH * 0.5f, color);
                if (in.hovered) {
                    Ui.MenuItem sub = drawMenu(itemId, it.children, x + width - 2f, cy);
                    if (sub != null) result = sub;
                }
            } else if (it.enabled && in.clicked) {
                result = it;
            }
            cy += rowH;
        }
        return result;
    }

    private boolean menuHitAny(String pathId, Ui.MenuItem[] items, float x, float y) {
        float rowH = 32f;
        float pad = 10f;
        float width = 160f;
        for (Ui.MenuItem it : items) {
            if (it.label != null) {
                width = Math.max(width, ui.textWidth(Ui.Font.BODY, it.label) + pad * 2f + (it.hasChildren() ? 24f : 0f));
            }
        }
        float menuH = 0f;
        for (Ui.MenuItem it : items) menuH += it.isSeparator() ? 9f : rowH;
        if (x + width > ui.width) x = Math.max(0f, x - width);
        if (y + menuH > ui.height) y = Math.max(0f, y - menuH);
        if (ui.hit(x, y, width, menuH)) return true;
        float cy = y;
        for (int i = 0; i < items.length; i++) {
            Ui.MenuItem it = items[i];
            if (it.isSeparator()) {
                cy += 9f;
                continue;
            }
            if (it.hasChildren() && ui.hit(x, cy, width, rowH)
                    && menuHitAny(pathId + "#item" + i, it.children, x + width - 2f, cy)) {
                return true;
            }
            cy += rowH;
        }
        return false;
    }
}

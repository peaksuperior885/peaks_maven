package com.peak885.ui.shader;

import org.lwjgl.opengl.GL;

/**
 * Shader source loading with automatic GLSL version selection.
 * Prefers the highest supported GLSL version while remaining compatible
 * with GLSL 1.20 (OpenGL 2.1) when that is all that is available.
 */
public final class Glsl {

    /** GLSL version we will emit: 120 (legacy) or 150 / 330 (modern syntax). */
    public enum Version {
        GLSL_120(120, "#version 120\n"),
        GLSL_150(150, "#version 150\n"),
        GLSL_330(330, "#version 330 core\n");

        public final int number;
        public final String directive;

        Version(int number, String directive) {
            this.number = number;
            this.directive = directive;
        }
    }

    private static volatile Version detected;

    private Glsl() {
    }

    /**
     * Detect the best GLSL version the current context supports.
     * Safe to call after GL.createCapabilities().
     */
    public static Version detectVersion() {
        Version cached = detected;
        if (cached != null) {
            return cached;
        }
        synchronized (Glsl.class) {
            if (detected != null) {
                return detected;
            }
            try {
                // Prefer core 3.3+ when available
                if (GL.getCapabilities().OpenGL33) {
                    detected = Version.GLSL_330;
                } else if (GL.getCapabilities().OpenGL32
                        || GL.getCapabilities().OpenGL31
                        || GL.getCapabilities().OpenGL30) {
                    detected = Version.GLSL_150;
                } else {
                    detected = Version.GLSL_120;
                }
            } catch (Throwable t) {
                // No context or very old GL
                detected = Version.GLSL_120;
            }
            return detected;
        }
    }

    /**
     * Force a specific version (mainly for tests). Pass null to re-detect next time.
     */
    public static void forceVersion(Version version) {
        detected = version;
    }

    public static String loadShaderSource(String path) {
        return loadShaderSource(path, detectVersion());
    }

    public static String loadShaderSource(String path, Version version) {
        String source = Preprocessing.preprocess(path);
        boolean isFragment = path.endsWith(".frag") || path.contains("frag");
        return adaptToVersion(source, version, isFragment);
    }

    /**
     * Strip any existing #version and rewrite attribute/varying/gl_FragColor
     * so the same source works on both GLSL 1.20 and modern core profiles.
     */
    static String adaptToVersion(String source, Version version, boolean isFragment) {
        // Remove leading #version lines
        String[] lines = source.split("\n", -1);
        StringBuilder body = new StringBuilder();
        boolean sawVersion = false;
        for (String line : lines) {
            String trimmed = line.trim();
            if (!sawVersion && trimmed.startsWith("#version")) {
                sawVersion = true;
                continue;
            }
            body.append(line).append('\n');
        }
        String code = body.toString();

        if (version == Version.GLSL_120) {
            return version.directive + code;
        }

        // Modernise keywords
        code = code
                .replace("attribute ", "in ")
                .replace("texture2D(", "texture(")
                .replace("gl_FragColor", "fragColor");

        if (isFragment) {
            code = code.replace("varying ", "in ");
        } else {
            code = code.replace("varying ", "out ");
        }

        StringBuilder modern = new StringBuilder(version.directive);
        if (isFragment) {
            modern.append("out vec4 fragColor;\n");
        }
        modern.append(code);
        return modern.toString();
    }
}

package io.github.cottonmc.cotton.gui.impl.modmenu;

import net.minecraft.client.gui.GuiGraphics; // DrawContext -> GuiGraphics
import net.minecraft.resources.ResourceLocation; // Identifier -> ResourceLocation

import io.github.cottonmc.cotton.gui.client.ScreenDrawing;
import io.github.cottonmc.cotton.gui.impl.LibGuiCommon;
import io.github.cottonmc.cotton.gui.widget.WWidget;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;

public class WKirbSprite extends WWidget {
	// Identifier -> ResourceLocation.fromNamespaceAndPath
	private static final ResourceLocation KIRB = ResourceLocation.fromNamespaceAndPath(LibGuiCommon.MOD_ID, "textures/widget/kirb.png");

	private static final float PX = 1f/416f;
	private static final float KIRB_WIDTH = 32*PX;

	private int currentFrame = 0;
	private long currentFrameTime = 0;
	private final int[] toSleep = { 0, 0, 0, 1, 2, 1, 2, 0, 0, 0, 1, 2, 3 };
	private final int[] asleep = { 4, 4, 4, 4, 5, 6, 7, 6, 5 };
	private final int[] toAwake = { 3, 3, 8, 8, 8, 8, 8, 8, 8 };
	private final int[] awake = { 9, 9, 9, 10, 11, 12 };
	private State state = State.ASLEEP;
	private final ArrayList<Integer> pendingFrames = new ArrayList<>();

	private final int frameTime = 300;
	private long lastFrame;

	public WKirbSprite() {
		state = (shouldRenderInDarkMode()) ? State.ASLEEP : State.AWAKE;
	}

	public void schedule(int[] frames) {
		for (int i : frames) pendingFrames.add(i);
	}

	@Override
	public boolean canResize() {
		return false;
	}

	@Override
	public int getWidth() {
		return 32;
	}

	@Override
	public int getHeight() {
		return 32;
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public void paint(GuiGraphics context, int x, int y, int mouseX, int mouseY) { // DrawContext -> GuiGraphics
		long now = System.nanoTime() / 1_000_000L;

		if (pendingFrames.isEmpty()) {
			if (shouldRenderInDarkMode()) {
				state = switch (state) {
					case AWAKE -> State.FALLING_ASLEEP;
					case FALLING_ASLEEP -> State.ASLEEP;
					default -> /* zzzz */ State.ASLEEP;
				};
			} else {
				state = switch (state) {
					case ASLEEP -> State.WAKING_UP;
					case WAKING_UP -> State.AWAKE;
					default -> State.AWAKE;
				};
			}

			switch (state) {
				case ASLEEP -> schedule(asleep);
				case WAKING_UP -> schedule(toAwake);
				case AWAKE -> schedule(awake);
				case FALLING_ASLEEP -> schedule(toSleep);
			}
		}

		float offset = KIRB_WIDTH * currentFrame;
		ScreenDrawing.texturedRect(context, x, y + 8, 32, 32, KIRB, offset, 0, offset + KIRB_WIDTH, 1, 0xFFFFFFFF);

		long elapsed = now - lastFrame;
		currentFrameTime += elapsed;
		if (currentFrameTime >= frameTime) {
			if (!pendingFrames.isEmpty()) currentFrame = pendingFrames.remove(0);
			currentFrameTime = 0;
		}

		this.lastFrame = now;
	}

	public enum State {
		AWAKE,
		FALLING_ASLEEP,
		ASLEEP,
		WAKING_UP;
	}
}

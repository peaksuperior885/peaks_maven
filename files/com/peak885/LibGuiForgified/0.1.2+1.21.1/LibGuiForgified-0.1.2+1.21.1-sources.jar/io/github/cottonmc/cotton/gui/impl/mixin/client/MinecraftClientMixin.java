package io.github.cottonmc.cotton.gui.impl.mixin.client;

import net.minecraft.client.Minecraft;

import io.github.cottonmc.cotton.gui.impl.client.ItemUseChecker;

import net.minecraft.client.gui.screens.Screen;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
abstract class MinecraftClientMixin {
	@Inject(method = "setScreen", at = @At(value = "HEAD"), remap = false)
	private void onSetScreen(Screen screen, CallbackInfo info) {
	}
}

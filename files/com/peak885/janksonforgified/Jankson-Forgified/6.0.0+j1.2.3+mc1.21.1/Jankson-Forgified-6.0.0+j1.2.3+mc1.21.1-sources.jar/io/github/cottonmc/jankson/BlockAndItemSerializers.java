package io.github.cottonmc.jankson;

import java.util.Collection;
import java.util.Optional;

import blue.endless.jankson.JsonElement;
import blue.endless.jankson.JsonObject;
import blue.endless.jankson.JsonPrimitive;
import blue.endless.jankson.api.Marshaller;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

@SuppressWarnings("removal")
public class BlockAndItemSerializers {

	public static ItemStack getItemStack(JsonObject json, Marshaller m) {
		String itemIdString = json.get(String.class, "item");
		// 1.21.1 uses BuiltInRegistries for direct lookups
		Item item = BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse(itemIdString)).orElse(Items.AIR);
		ItemStack stack = new ItemStack(item);
		if (json.containsKey("count")) {
			Integer count = json.get(Integer.class, "count");
			if (count != null) {
				stack.setCount(count);
			}
		}
		return stack;
	}

	public static ItemStack getItemStackPrimitive(String s, Marshaller m) {
		Item item = BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse(s)).orElse(Items.AIR);
		return new ItemStack(item);
	}

	public static JsonElement saveItemStack(ItemStack stack, Marshaller m) {
		String idStr = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
		if (stack.getCount() == 1) return new JsonPrimitive(idStr);

		JsonObject result = new JsonObject();
		result.put("item", new JsonPrimitive(idStr));
		result.put("count", new JsonPrimitive(stack.getCount()));
		return result;
	}

	@Deprecated
	public static Block getBlockPrimitive(String blockIdString, Marshaller m) {
		return BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(blockIdString)).orElse(null);
	}

	@Deprecated
	public static JsonElement saveBlock(Block block, Marshaller m) {
		return new JsonPrimitive(BuiltInRegistries.BLOCK.getKey(block).toString());
	}

	public static BlockState getBlockStatePrimitive(String blockIdString, Marshaller m) {
		Optional<Block> blockOpt = BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(blockIdString));
		// Yarn: getDefaultState() -> Mojang: defaultBlockState()
		return blockOpt.map(Block::defaultBlockState).orElse(null);
	}

	/**
	 * @param json A json object representing a BlockState
	 * @return the BlockState represented, or null if the object does not represent a valid BlockState.
	 */
	public static BlockState getBlockState(JsonObject json, Marshaller m) {
		String blockIdString = json.get(String.class, "block");

		Block block = BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(blockIdString)).orElse(null);
		if (block == null) return null;

		BlockState state = block.defaultBlockState();
		JsonObject stateObject = json.getObject("BlockStateTag");
		if (stateObject == null) stateObject = json;

		Collection<Property<?>> properties = state.getProperties();
		for (String key : stateObject.keySet()) {
			if (stateObject == json && (key.equals("BlockStateTag") || key.equals("block"))) continue;

			for (Property<?> property : properties) {
				if (property.getName().equals(key)) {
					String val = stateObject.get(String.class, key);
					state = withProperty(state, property, val);
					break;
				}
			}
		}

		return state;
	}

	public static JsonElement saveBlockState(BlockState state, Marshaller m) {
		Block defaultBlock = state.getBlock();
		BlockState defaultState = defaultBlock.defaultBlockState();
		String blockKey = BuiltInRegistries.BLOCK.getKey(defaultBlock).toString();

		if (state.equals(defaultState)) {
			return new JsonPrimitive(blockKey);
		} else {
			JsonObject result = new JsonObject();
			result.put("block", new JsonPrimitive(blockKey));
			JsonObject stateObject = result;
			for (Property<?> property : state.getProperties()) {
				String key = property.getName();
				if (key.equals("block") || key.equals("BlockStateTag")) {
					stateObject = new JsonObject();
					result.put("BlockStateTag", stateObject);
					break;
				}
			}

			for (Property<?> property : state.getProperties()) {
				if (state.getValue(property).equals(defaultState.getValue(property))) continue;
				String key = property.getName();
				String val = getProperty(state, property);
				stateObject.put(key, new JsonPrimitive(val));
			}

			return result;
		}
	}

	public static <T extends Comparable<T>> BlockState withProperty(BlockState state, Property<T> property, String stringValue) {
		Optional<T> val = property.getValue(stringValue);
		// Yarn: state.with() -> Mojang: state.setValue()
		return val.map(t -> state.setValue(property, t)).orElse(state);
	}

	public static <T extends Comparable<T>> String getProperty(BlockState state, Property<T> property) {
		// Yarn: property.name() -> Mojang: property.getName()
		return property.getName(state.getValue(property));
	}
}
package com.peak885.janksonforgified;

import net.minecraftforge.fml.common.Mod;

@Mod(JanksonForgified.MODID)
public class JanksonForgified {
    public static final String MODID = "cotton_jackson";
}